# Publicação · Gestão de Pessoas · Grupo L. Cirne

Arquitetura: **Internet → Caddy (HTTPS automático) → app (Node) → PostgreSQL**.
Só as portas 80 e 443 ficam abertas. O banco não tem porta publicada e roda numa rede interna sem saída para a internet.

> ⚠️ **Não publique o HTML antigo (`GESTAO-DE-PESSOAS_Grupo-L-Cirne.html`).** Ele tem senhas em texto puro e dados simulados no próprio arquivo. Só a pasta `frontend/` deste projeto vai ao ar.

> ⚠️ **Nunca carregue `backend/test/fixtures.sql` em produção.** Ele cria usuários de teste com senha conhecida. Ele só serve aos testes automatizados e não entra na imagem Docker.

## O que você precisa (uma vez)

| Item | Detalhe |
|---|---|
| **Servidor** | VPS Linux (Ubuntu 24.04), 2 vCPU / 2–4 GB RAM / 20 GB de disco são suficientes para centenas de usuários. Prefira datacenter no Brasil (latência e LGPD). |
| **Domínio** | Ex.: `rh.grupolcirne.com.br`. Crie um registro **A** apontando para o IP do servidor **antes** de subir (o certificado HTTPS depende disso). |
| **Portas** | 80 e 443 liberadas no firewall do provedor. |

## Passo a passo

### 1. Preparar o servidor
```bash
# como root ou com sudo
apt update && apt -y upgrade
curl -fsSL https://get.docker.com | sh          # instala Docker + Compose
ufw allow OpenSSH && ufw allow 80 && ufw allow 443 && ufw enable
```
Recomendado: acesso por **chave SSH** (desative login por senha em `/etc/ssh/sshd_config`) e um usuário que não seja root.

### 2. Enviar o projeto
Copie a pasta `lcirne-erp/` para o servidor (ex.: `scp -r lcirne-erp usuario@IP:~/`). Não envie `node_modules` nem arquivos `.env` do seu computador.

### 3. Configurar os segredos
```bash
cd ~/lcirne-erp
cp .env.production.example .env
chmod 600 .env
openssl rand -base64 24 | tr -d '/+='    # cole em POSTGRES_PASSWORD
openssl rand -base64 48                  # cole em JWT_SECRET
nano .env                                # ajuste DOMINIO
```
O `.env` fica **só no servidor**. Se ele vazar, troque `JWT_SECRET` (derruba todas as sessões) e a senha do banco.

### 4. Subir
```bash
docker compose up -d --build
docker compose logs -f app       # deve mostrar as migrações aplicadas e "na porta 3333 (produção)"
```
As migrações rodam sozinhas a cada subida (só aplicam o que ainda não foi aplicado).
Se o `app` recusar iniciar com **CONFIGURAÇÃO INSEGURA**, o `JWT_SECRET` está vazio, curto ou de exemplo.

### 5. Liberar o Administrador Master (uma vez)
O usuário `admin.master` nasce **bloqueado**: ninguém entra até você executar:
```bash
docker compose exec app node scripts/bootstrap-admin.js
```
Ele imprime uma senha aleatória **uma única vez**. Anote em um cofre de senhas. No primeiro login o sistema obriga a trocar.
> Não rode este comando de novo em produção: ele redefine a senha do admin.

### 6. Conferir
Abra `https://SEU-DOMINIO`. O cadeado deve aparecer. Teste: `https://SEU-DOMINIO/health` → `{"status":"ok"}`.

### 7. Cadastrar as pessoas
Login como `admin.master` → **Colaboradores** (cadastre a ficha: empresa, cargo, gestor direto) → **Usuários e senhas** (crie o acesso vinculado à ficha). O sistema mostra a **senha temporária uma única vez**; repasse por canal seguro (pessoalmente ou mensagem individual). No primeiro acesso a pessoa é obrigada a trocar.
Crie também os usuários do RH (`Gestor/RH`) e não use o `admin.master` no dia a dia.

**Ordem certa do cadastro:** primeiro os *gestores* (para poder informar o "gestor direto" dos demais), depois os liderados. É o vínculo `gestor direto` que define o que cada líder enxerga.

## Operação

**Atualizar o sistema**
```bash
cd ~/lcirne-erp && docker compose up -d --build
```
(Novos arquivos de migração precisam ser incluídos na lista `ORDEM` de `backend/scripts/migrate.js`.)

**Backups.** O serviço `backup` gera um dump diário em `./backups` (retenção `RETENCAO_DIAS`, padrão 30). **Isso fica no mesmo servidor**: se o servidor for perdido, os backups vão junto. Copie para fora, por exemplo:
```bash
# cron diário no servidor (crontab -e); exemplo com rclone configurado para um armazenamento externo
30 3 * * * rclone copy ~/lcirne-erp/backups remoto:lcirne-backups --max-age 48h
```
**Restaurar (teste isso antes de ir ao ar, em um ambiente separado):**
```bash
docker compose stop app
gunzip -c backups/lcirne_AAAAMMDD_HHMMSS.sql.gz | docker compose exec -T db psql -U lcirne -d lcirne_rh
docker compose start app
```
> Um backup que nunca foi restaurado não é backup. Faça o teste de restauração.

**Monitoramento.** Configure um monitor externo gratuito (ex.: UptimeRobot) em `https://SEU-DOMINIO/health`. Acompanhe erros com `docker compose logs --tail=200 app`.

**Atrás de Cloudflare ou outro proxy?** Ajuste `TRUST_PROXY_HOPS` (2 se houver dois proxies). Errado, o limite de tentativas de login passa a tratar todos como o mesmo IP.

## Checklist antes de liberar para todos

- [ ] Domínio com HTTPS válido e `/health` respondendo
- [ ] `admin.master` liberado, senha trocada e guardada em cofre
- [ ] Teste de restauração de backup feito com sucesso + cópia externa configurada
- [ ] Um acesso de teste de **cada perfil** conferido (Gestor/RH, Líder, Colaborador): o colaborador não vê ninguém além de si
- [ ] **Piloto** com o RH e 3–5 líderes por 1–2 semanas antes de abrir para todos
- [ ] Perguntas e "pegadinhas" do mapa de liderança **revisadas por profissional de RH/psicologia organizacional**
- [ ] **LGPD:** o sistema trata dados pessoais e **sensíveis** (atestados/saúde, CPF, salário). Defina o encarregado (DPO), a base legal, o aviso de privacidade aos colaboradores e quem no RH pode acessar o quê. Isto exige validação jurídica; este guia não substitui.
- [ ] Combinado interno: senha temporária nunca por e-mail em texto aberto/grupo de WhatsApp

## Limites conhecidos desta versão

- **Sem "esqueci minha senha" por e-mail.** O RH redefine e informa uma senha temporária.
- **Recarregar a página (F5) exige novo login.** É intencional: o token fica só na memória do navegador, o que reduz o risco de roubo de sessão.
- **Módulos da versão antiga ainda não migrados** (treinamentos, onboarding, SAC, 9-Box etc.): existem no banco/API apenas Colaboradores, Usuários, Atestados, Pesquisas, PDI e Liderança; no portal estão Colaboradores, Usuários, PDI e Liderança. Atestados e Pesquisas já têm API, mas ainda não têm telas.
- **Painel de módulos/permissões (ativar módulo, matriz CRUD por perfil)** existe na API (`/api/modulos/*`, só Administrador Master), mas ainda **não tem tela**.
- **Cadastro em massa (planilha)** ainda não existe: cada colaborador é cadastrado pela tela.
- Os arquivos Docker e o Caddyfile foram escritos e validados na sintaxe, mas **não foram construídos/executados em um servidor real** por quem os preparou; por isso o piloto e o passo 6 são obrigatórios.
