#!/bin/sh
# Backup diário do banco (pg_dump comprimido) com retenção configurável.
# ATENÇÃO: este backup fica NO MESMO servidor. Copie ./backups para fora dele (ver DEPLOY.md).
umask 077
while true; do
  arq="/backups/lcirne_$(date +%Y%m%d_%H%M%S).sql.gz"
  if pg_dump -h db -U "$POSTGRES_USER" "$POSTGRES_DB" | gzip > "$arq.tmp"; then
    mv "$arq.tmp" "$arq"; echo "backup ok: $arq"
  else
    rm -f "$arq.tmp"; echo "FALHA NO BACKUP" >&2
  fi
  find /backups -name 'lcirne_*.sql.gz' -mtime +"${RETENCAO_DIAS:-30}" -delete
  sleep 86400
done
