-- =========================================================
-- MÓDULO LIDERANÇA · banco de questões editável + plano automático
-- Ordem: schema.sql -> 002_modulo_pdi.sql -> 004 (este) -> 005_seed_...
-- =========================================================

-- Dimensões de liderança (D1..D8) — editáveis pelo RH
CREATE TABLE lid_dimensoes (
  id          SERIAL PRIMARY KEY,
  chave       VARCHAR(10) UNIQUE NOT NULL,     -- 'D1'..'D8'
  nome        VARCHAR(120) NOT NULL,
  cor         VARCHAR(9),
  descricao   TEXT,
  leitura_alto  TEXT,
  leitura_baixo TEXT,
  ordem       INTEGER NOT NULL DEFAULT 0,
  ativo       BOOLEAN NOT NULL DEFAULT TRUE
);

-- Banco de questões.
--  tipo 'normal'    = situação com melhor resposta razoavelmente identificável
--  tipo 'pegadinha' = tem ao menos uma opção "de vitrine": soa politicamente
--                     correta, mas é a resposta errada para aquele contexto.
--  par_id           = questão-espelho da mesma competência (mede consistência)
--  substitui_id     = versionamento: editar questão que já foi respondida cria
--                     nova versão e desativa a antiga (mapas antigos não mudam)
CREATE TABLE lid_questoes (
  id            SERIAL PRIMARY KEY,
  dimensao_id   INTEGER NOT NULL REFERENCES lid_dimensoes(id),
  parte         SMALLINT NOT NULL DEFAULT 1 CHECK (parte IN (1,2)),
  tipo          VARCHAR(12) NOT NULL DEFAULT 'normal' CHECK (tipo IN ('normal','pegadinha')),
  texto         TEXT NOT NULL,
  par_id        INTEGER REFERENCES lid_questoes(id) ON DELETE SET NULL,
  substitui_id  INTEGER REFERENCES lid_questoes(id) ON DELETE SET NULL,
  ordem         INTEGER NOT NULL DEFAULT 0,
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_lidq_dim ON lid_questoes(dimensao_id) WHERE ativo;

CREATE TABLE lid_opcoes (
  id          SERIAL PRIMARY KEY,
  questao_id  INTEGER NOT NULL REFERENCES lid_questoes(id) ON DELETE CASCADE,
  texto       TEXT NOT NULL,
  pontos      SMALLINT NOT NULL CHECK (pontos BETWEEN 1 AND 5),
  vitrine     BOOLEAN NOT NULL DEFAULT FALSE,  -- opção que "soa bem" mas é armadilha
  ordem       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_lido_q ON lid_opcoes(questao_id);

-- Faixas de resultado (Consolidado / Desenvolvido / ...) — editáveis
CREATE TABLE lid_faixas (
  id       SERIAL PRIMARY KEY,
  chave    VARCHAR(30) UNIQUE NOT NULL,
  rotulo   VARCHAR(60) NOT NULL,
  pct_min  INTEGER NOT NULL,
  cor      VARCHAR(9),
  leitura  TEXT
);

-- Parâmetros do motor (limiares editáveis pelo RH)
CREATE TABLE lid_config (
  chave  VARCHAR(40) PRIMARY KEY,
  valor  NUMERIC NOT NULL,
  descricao TEXT
);

-- Regras FIXAS do plano de desenvolvimento.
--  gatilho 'dimensao'      : dimensão com pct entre pct_min e pct_max
--  gatilho 'consistencia'  : gap médio entre partes >= limiar
--  gatilho 'vitrine'       : índice de respostas de vitrine >= limiar
--  gatilho 'faixa'         : resultado geral cai na faixa indicada
CREATE TABLE lid_regras_plano (
  id           SERIAL PRIMARY KEY,
  gatilho      VARCHAR(14) NOT NULL CHECK (gatilho IN ('dimensao','consistencia','vitrine','faixa')),
  dimensao_id  INTEGER REFERENCES lid_dimensoes(id) ON DELETE CASCADE,
  pct_min      INTEGER,
  pct_max      INTEGER,
  faixa_chave  VARCHAR(30),
  titulo       VARCHAR(160) NOT NULL,
  descricao    TEXT NOT NULL,
  tipo_acao    VARCHAR(20) NOT NULL DEFAULT 'pratica', -- treinamento|leitura|mentoria|pratica|conversa
  prazo_dias   INTEGER NOT NULL DEFAULT 60,
  prioridade   SMALLINT NOT NULL DEFAULT 2,             -- 1 alta .. 3 baixa
  ativo        BOOLEAN NOT NULL DEFAULT TRUE
);

-- Mapa aplicado a um líder
CREATE TABLE lid_mapas (
  id              SERIAL PRIMARY KEY,
  colaborador_id  INTEGER NOT NULL REFERENCES colaboradores(id) ON DELETE CASCADE,
  aplicado_por    INTEGER REFERENCES usuarios(id),
  autoaplicacao   BOOLEAN NOT NULL DEFAULT TRUE,
  geral_pct       INTEGER NOT NULL,
  faixa_chave     VARCHAR(30),
  gap_medio       NUMERIC(5,1),
  indice_vitrine  INTEGER,                 -- % de pegadinhas em que caiu na opção de vitrine
  confiabilidade  VARCHAR(10) NOT NULL,    -- alta|media|baixa
  resultado       JSONB NOT NULL,          -- pct por dimensão, alertas
  criado_em       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_lidm_colab ON lid_mapas(colaborador_id, criado_em DESC);

CREATE TABLE lid_respostas (
  id          SERIAL PRIMARY KEY,
  mapa_id     INTEGER NOT NULL REFERENCES lid_mapas(id) ON DELETE CASCADE,
  questao_id  INTEGER NOT NULL REFERENCES lid_questoes(id),
  opcao_id    INTEGER NOT NULL REFERENCES lid_opcoes(id),
  pontos      SMALLINT NOT NULL,           -- snapshot: editar a opção depois não altera o mapa
  vitrine     BOOLEAN NOT NULL,
  UNIQUE(mapa_id, questao_id)
);

-- Plano gerado a partir do mapa (RH revisa antes de enviar ao PDI)
CREATE TABLE lid_planos (
  id          SERIAL PRIMARY KEY,
  mapa_id     INTEGER NOT NULL UNIQUE REFERENCES lid_mapas(id) ON DELETE CASCADE,
  status      VARCHAR(12) NOT NULL DEFAULT 'rascunho' CHECK (status IN ('rascunho','aprovado','no_pdi')),
  aprovado_por INTEGER REFERENCES usuarios(id),
  criado_em   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE lid_plano_acoes (
  id          SERIAL PRIMARY KEY,
  plano_id    INTEGER NOT NULL REFERENCES lid_planos(id) ON DELETE CASCADE,
  regra_id    INTEGER REFERENCES lid_regras_plano(id) ON DELETE SET NULL,
  dimensao_id INTEGER REFERENCES lid_dimensoes(id),
  titulo      VARCHAR(160) NOT NULL,
  descricao   TEXT NOT NULL,
  tipo_acao   VARCHAR(20) NOT NULL,
  prazo_dias  INTEGER NOT NULL,
  prioridade  SMALLINT NOT NULL,
  incluir     BOOLEAN NOT NULL DEFAULT TRUE   -- RH pode desmarcar ações antes de aprovar
);

-- Destino das ações aprovadas: tabela pdi_planos (002_modulo_pdi.sql). Guardamos de qual mapa cada item veio.
ALTER TABLE pdi_planos ADD COLUMN mapa_id INTEGER REFERENCES lid_mapas(id) ON DELETE SET NULL;
CREATE INDEX idx_pdi_mapa ON pdi_planos(mapa_id);

CREATE TRIGGER trg_audit_lid_questoes AFTER INSERT OR UPDATE OR DELETE ON lid_questoes
  FOR EACH ROW EXECUTE FUNCTION fn_auditoria();
CREATE TRIGGER trg_audit_lid_regras AFTER INSERT OR UPDATE OR DELETE ON lid_regras_plano
  FOR EACH ROW EXECUTE FUNCTION fn_auditoria();
CREATE TRIGGER trg_audit_lid_mapas AFTER INSERT OR UPDATE OR DELETE ON lid_mapas
  FOR EACH ROW EXECUTE FUNCTION fn_auditoria();

INSERT INTO lid_config (chave, valor, descricao) VALUES
  ('limiar_gap',          25, 'Diferença (em pontos %) entre parte 1 e parte 2 de uma dimensão que indica inconsistência'),
  ('limiar_vitrine',      50, '% de pegadinhas respondidas com a opção de vitrine a partir do qual o resultado é marcado como pouco confiável'),
  ('max_dimensoes_plano',  3, 'Quantas dimensões mais fracas entram no plano (evita plano inexequível)'),
  ('pct_dimensao_reforco', 75, 'Dimensão abaixo disso é considerada para o plano');
