// Uso: node gerar-seed-lideranca.js <caminho-do-html> > ../005_seed_lideranca_banco_editavel.sql
const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync(process.argv[2], 'utf8');
function extrair(nome) {
  const ini = html.indexOf(`const ${nome} = [`);
  if (ini < 0) throw new Error(`${nome} não encontrado`);
  const fim = html.indexOf('\n];', ini);
  return vm.runInNewContext(`(${html.slice(ini + `const ${nome} = `.length, fim + 2)})`);
}
const DIMS = extrair('DIMENSOES_LIDERANCA');
const QUESTOES = extrair('QUESTOES_LIDERANCA');
const FAIXAS = extrair('FAIXAS_LIDERANCA');

const q = (s) => (s === null || s === undefined ? 'NULL' : `'${String(s).replace(/'/g, "''")}'`);
const out = [];
const w = (s) => out.push(s);

w('-- GERADO por tools/gerar-seed-lideranca.js — não edite à mão; edite o gerador ou use o painel do RH.');
w('BEGIN;');

DIMS.forEach((d, i) => w(
  `INSERT INTO lid_dimensoes (chave,nome,cor,descricao,leitura_alto,leitura_baixo,ordem) VALUES (${q(d.id)},${q(d.nome)},${q(d.cor)},${q(d.desc)},${q(d.alto)},${q(d.baixo)},${i + 1});`));

FAIXAS.forEach((f) => w(
  `INSERT INTO lid_faixas (chave,rotulo,pct_min,cor,leitura) VALUES (${q(f.id)},${q(f.rotulo)},${f.min},${q(f.cor)},${q(f.leitura)});`));

// ---- Questões originais (numeração n preservada em "ordem") -----------------
const idxPorN = {};
QUESTOES.forEach((qs, i) => {
  idxPorN[qs.n] = i;
  w(`INSERT INTO lid_questoes (dimensao_id,parte,tipo,texto,ordem) VALUES ((SELECT id FROM lid_dimensoes WHERE chave=${q(qs.dim)}),${qs.parte},'normal',${q(qs.texto)},${qs.n});`);
  qs.opcoes.forEach((o, k) => w(
    `INSERT INTO lid_opcoes (questao_id,texto,pontos,ordem) VALUES ((SELECT id FROM lid_questoes WHERE ordem=${qs.n} AND tipo='normal'),${q(o)},${qs.pontos[k]},${k});`));
});

// ---- PEGADINHAS -------------------------------------------------------------
// Cada uma espelha (par) uma questão original da mesma dimensão. A opção
// "vitrine" é a que soa como resposta-modelo de livro de liderança, mas é a
// errada naquele contexto. Quem escolhe sempre a vitrine está respondendo o
// que "deveria" dizer, não o que faria.
// [n_do_par, dim, texto, [[opção, pontos, vitrine?], ...]]
const PEGADINHAS = [
  [1, 'D1', 'Seu melhor vendedor está há dois meses abaixo da meta e você sabe que ele passa por um momento pessoal difícil.', [
    ['Como ele sempre entregou, dou um tempo sem cobrar nada e espero ele se recuperar.', 2, true],
    ['Converso em particular, acolho o momento, mas combino metas intermediárias curtas e uma data para revisarmos juntos.', 5],
    ['Mantenho a cobrança exatamente igual à dos demais para não abrir precedente.', 2],
    ['Peço ao RH que converse com ele e aguardo o retorno antes de qualquer ação minha.', 3]]],
  [2, 'D3', 'Você delegou um projeto importante a um colaborador que nunca o conduziu. Ele diz que está tudo sob controle, mas você não recebe nenhuma atualização há duas semanas.', [
    ['Confio nele e não interfiro: delegar é dar autonomia de verdade.', 2, true],
    ['Assumo o projeto para garantir o prazo.', 1],
    ['Peço um ponto de acompanhamento curto, combino marcos de entrega e o que ele precisa de mim, sem tirar a responsabilidade dele.', 5],
    ['Passo a exigir um relatório detalhado todos os dias.', 2]]],
  [3, 'D5', 'Dois integrantes da equipe discordam abertamente e um deles pede que você "escolha um lado".', [
    ['Reúno os dois e proponho que cada um ceda metade, para encerrar logo o assunto.', 2, true],
    ['Decido pelo lado com mais razão técnica e comunico a decisão a todos.', 3],
    ['Ouço cada um separadamente, identifico o que está de fato em jogo (meta, cliente, papel) e só depois conduzo uma conversa conjunta a partir disso.', 5],
    ['Digo que são adultos e devem resolver sozinhos.', 1]]],
  [4, 'D7', 'Você discorda de uma mudança de processo definida pela diretoria, mas ela já foi aprovada.', [
    ['Apresento a mudança à equipe como se fosse minha convicção, para ninguém perder a confiança na empresa.', 2, true],
    ['Digo abertamente à equipe que tenho ressalvas, explico o motivo da mudança, recolho as preocupações e as levo à diretoria.', 5],
    ['Deixo claro que discordo e que só vou cumprir porque sou obrigado.', 1],
    ['Aplico a mudança aos poucos e apenas na parte que considero útil.', 2]]],
  [5, 'D2', 'Um colaborador com bom desempenho pede feedback e você percebe que ele espera ouvir elogios.', [
    ['Destaco só os pontos fortes, para não desmotivar quem já entrega bem.', 2, true],
    ['Elogio de forma geral e deixo a parte de melhoria para a avaliação anual.', 2],
    ['Reconheço com exemplos concretos o que ele faz bem e apresento uma oportunidade específica de crescimento, combinando como vou apoiá-lo.', 5],
    ['Entrego uma lista completa de tudo que pode melhorar, para ele evoluir mais rápido.', 3]]],
  [6, 'D6', 'Seu próprio gestor faz uma crítica dura ao seu trabalho na frente da equipe.', [
    ['Agradeço a crítica, mantenho a calma e não volto ao assunto depois.', 2, true],
    ['Respondo na hora, defendendo meus argumentos, para a equipe não me ver como fraco.', 1],
    ['Mantenho a compostura na hora, depois peço uma conversa reservada para entender a crítica e, se fizer sentido, corrijo o rumo com a equipe.', 5],
    ['Aceito a crítica e repasso a cobrança a quem errou no meu time.', 1]]],
  [7, 'D4', 'Dois vendedores, um experiente e outro em início de carreira, cometem o mesmo erro no mesmo procedimento.', [
    ['Trato os dois exatamente igual, para ser justo e evitar favoritismo.', 2, true],
    ['Cobro mais autonomia do experiente e ensino o iniciante passo a passo, deixando claro para ambos o critério.', 5],
    ['Deixo o experiente resolver sozinho e acompanho o iniciante de perto, sem explicar a diferença.', 3],
    ['Aplico advertência formal nos dois.', 1]]],
  [8, 'D8', 'As equipes de Postos e de Pneus culpam uma à outra por um atraso que prejudicou um cliente em comum.', [
    ['Marco uma reunião em que cada área conta sua versão e todos concordam em colaborar mais.', 3, true],
    ['Reconstituo o fluxo do pedido com as duas áreas, identifico o ponto de falha e combino um acordo operacional com responsável e prazo.', 5],
    ['Aponto quem errou e peço que se desculpe.', 2],
    ['Reporto ao meu gestor para ele decidir.', 1]]],
];
PEGADINHAS.forEach(([par, dim, texto, ops], i) => {
  const n = 100 + i + 1;
  w(`INSERT INTO lid_questoes (dimensao_id,parte,tipo,texto,ordem,par_id) VALUES ((SELECT id FROM lid_dimensoes WHERE chave=${q(dim)}),2,'pegadinha',${q(texto)},${n},(SELECT id FROM lid_questoes WHERE ordem=${par} AND tipo='normal'));`);
  ops.forEach(([t, p, v], k) => w(
    `INSERT INTO lid_opcoes (questao_id,texto,pontos,vitrine,ordem) VALUES ((SELECT id FROM lid_questoes WHERE ordem=${n} AND tipo='pegadinha'),${q(t)},${p},${v ? 'TRUE' : 'FALSE'},${k});`));
});

// ---- REGRAS FIXAS DO PLANO ---------------------------------------------------
// por dimensão: [intensivo (<60%), reforço (60–74%)]  = [titulo, descricao, tipo, prazo]
const R = {
  D1: [['Treino de conversa de cobrança com fatos', 'Roteiro de 4 passos (fato, impacto, expectativa, prazo) praticado em 3 conversas reais, com registro no 1:1 e revisão com o RH.', 'treinamento', 45],
       ['Rotina semanal de acompanhamento de metas', 'Definir metas intermediárias por pessoa e revisar toda semana por 8 semanas.', 'pratica', 60]],
  D2: [['Formação em feedback (modelo situação-comportamento-impacto)', 'Curso curto + 5 feedbacks aplicados e discutidos com um mentor.', 'treinamento', 45],
       ['Um feedback de desenvolvimento por liderado por mês', 'Registrar no PDI de cada liderado um ponto forte e uma oportunidade concreta.', 'pratica', 60]],
  D3: [['Prática guiada de delegação', 'Delegar 3 entregas completas (resultado esperado, prazo, limites) e resistir a reassumir; revisar com mentor.', 'mentoria', 60],
       ['Matriz de delegação da equipe', 'Mapear tarefas que só o líder faz e transferir ao menos duas nas próximas semanas.', 'pratica', 45]],
  D4: [['Leitura e discussão: liderança situacional', 'Ler o material indicado e discutir com o RH como ajustar o estilo a cada liderado.', 'leitura', 45],
       ['Mapa de maturidade da equipe', 'Classificar cada liderado por preparo e motivação e ajustar o nível de apoio por pessoa.', 'pratica', 30]],
  D5: [['Oficina de mediação de conflitos', 'Treinar escuta individual, levantamento de interesses e conversa conjunta; aplicar em 1 caso real.', 'treinamento', 60],
       ['Acompanhamento de um conflito real com o RH', 'Conduzir uma mediação com apoio de um par do RH e revisar o resultado depois.', 'mentoria', 45]],
  D6: [['Programa de autogestão sob pressão', 'Trilha de autoconhecimento com técnicas de regulação; check-in quinzenal com mentor.', 'treinamento', 90],
       ['Pedido de feedback ao próprio time', 'Pedir de forma segura a 3 liderados como sua reação à pressão afeta o time e definir 1 ajuste.', 'conversa', 45]],
  D7: [['Condução de mudanças: comunicar o porquê', 'Preparar e aplicar um roteiro de comunicação de mudança (motivo, impacto, apoio) em um caso real.', 'treinamento', 60],
       ['Revisão de decisões com dados novos', 'Registrar 2 decisões em que revisou o plano diante de fatos novos e o resultado.', 'pratica', 60]],
  D8: [['Projeto conjunto entre duas áreas', 'Liderar uma pequena entrega com participação de outra área, com rituais de alinhamento.', 'pratica', 75],
       ['Almoço/visita técnica entre equipes', 'Promover encontro mensal entre as áreas envolvidas nos principais fluxos.', 'pratica', 45]],
};
Object.entries(R).forEach(([dim, [intens, refor]]) => {
  w(`INSERT INTO lid_regras_plano (gatilho,dimensao_id,pct_min,pct_max,titulo,descricao,tipo_acao,prazo_dias,prioridade) VALUES ('dimensao',(SELECT id FROM lid_dimensoes WHERE chave=${q(dim)}),0,59,${q(intens[0])},${q(intens[1])},${q(intens[2])},${intens[3]},1);`);
  w(`INSERT INTO lid_regras_plano (gatilho,dimensao_id,pct_min,pct_max,titulo,descricao,tipo_acao,prazo_dias,prioridade) VALUES ('dimensao',(SELECT id FROM lid_dimensoes WHERE chave=${q(dim)}),60,74,${q(refor[0])},${q(refor[1])},${q(refor[2])},${refor[3]},2);`);
});
w(`INSERT INTO lid_regras_plano (gatilho,titulo,descricao,tipo_acao,prazo_dias,prioridade) VALUES ('consistencia','Conversa de calibragem sobre respostas inconsistentes','As respostas para situações parecidas divergiram muito. O RH deve conversar com o líder sobre casos reais recentes antes de fechar o diagnóstico.','conversa',15,1);`);
w(`INSERT INTO lid_regras_plano (gatilho,titulo,descricao,tipo_acao,prazo_dias,prioridade) VALUES ('vitrine','Validar o resultado com avaliação 360° e observação','O padrão de respostas sugere que o líder respondeu o que "deveria" fazer. Confirmar o diagnóstico com feedback dos liderados e do gestor antes de definir ações definitivas.','conversa',30,1);`);
w(`INSERT INTO lid_regras_plano (gatilho,faixa_chave,titulo,descricao,tipo_acao,prazo_dias,prioridade) VALUES ('faixa','consolidado','Atuar como mentor de outros líderes','Resultado consolidado: convidar para mentorar um líder em desenvolvimento e compartilhar boas práticas em encontro de liderança.','mentoria',90,3);`);
w(`INSERT INTO lid_regras_plano (gatilho,faixa_chave,titulo,descricao,tipo_acao,prazo_dias,prioridade) VALUES ('faixa','atencao','Acompanhamento próximo do RH por 90 dias','Resultado geral em faixa de atenção: encontros quinzenais com o RH e o gestor direto para acompanhar a execução do plano.','conversa',90,1);`);

w('COMMIT;');
console.log(out.join('\n'));
