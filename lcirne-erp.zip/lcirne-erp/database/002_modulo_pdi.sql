-- =========================================================
-- 002_modulo_pdi.sql — PDI (Plano de Desenvolvimento Individual) e 1:1s
-- Rodar depois do schema.sql. A ligação com o mapa de liderança
-- (coluna pdi_planos.mapa_id) é criada em 004_lideranca_banco_editavel.sql.
-- =========================================================

CREATE TABLE pdi_planos (
  id            SERIAL PRIMARY KEY,
  colaborador_id INTEGER NOT NULL REFERENCES colaboradores(id) ON DELETE CASCADE,
  ciclo         VARCHAR(20) NOT NULL,
  objetivo      TEXT NOT NULL,
  acoes         TEXT NOT NULL,
  prazo         DATE,
  status        VARCHAR(20) NOT NULL DEFAULT 'rascunho', -- rascunho|em_andamento|concluido
  origem        VARCHAR(30) NOT NULL DEFAULT 'manual',    -- manual|mapa_lideranca
  criado_por    INTEGER REFERENCES usuarios(id),
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now(),
  atualizado_em TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_pdi_colab ON pdi_planos(colaborador_id);
CREATE TRIGGER trg_audit_pdi AFTER INSERT OR UPDATE OR DELETE ON pdi_planos
  FOR EACH ROW EXECUTE FUNCTION fn_auditoria();
CREATE TRIGGER trg_touch_pdi BEFORE UPDATE ON pdi_planos
  FOR EACH ROW EXECUTE FUNCTION fn_atualizado_em();

-- 1:1s ligados ao PDI (acompanhamento periódico)
CREATE TABLE um_a_um (
  id            SERIAL PRIMARY KEY,
  colaborador_id INTEGER NOT NULL REFERENCES colaboradores(id) ON DELETE CASCADE,
  pdi_id        INTEGER REFERENCES pdi_planos(id),
  responsavel_id INTEGER REFERENCES usuarios(id),
  data_reuniao  DATE NOT NULL,
  pauta         TEXT,
  proximos_passos TEXT,
  status        VARCHAR(20) NOT NULL DEFAULT 'agendada', -- agendada|realizada|cancelada
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
