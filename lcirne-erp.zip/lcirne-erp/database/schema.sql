-- =========================================================
-- GESTÃO DE PESSOAS · Grupo L. Cirne
-- Schema PostgreSQL — modelagem relacional completa
-- =========================================================
-- Como rodar:
--   createdb lcirne_rh
--   psql lcirne_rh -f schema.sql
-- =========================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- crypt()/gen_salt() para hash bcrypt no seed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =========================================================
-- 1) EMPRESAS / UNIDADES
-- =========================================================
CREATE TABLE empresas (
  id            SERIAL PRIMARY KEY,
  chave         VARCHAR(30) UNIQUE NOT NULL,        -- ex: 'motos','postos','pneus','baterias'
  nome          VARCHAR(150) NOT NULL,
  cnpj          VARCHAR(20),
  cor_tema      VARCHAR(9),                          -- ex: '#df2a2a'
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE unidades (
  id            SERIAL PRIMARY KEY,
  empresa_id    INTEGER NOT NULL REFERENCES empresas(id) ON DELETE RESTRICT,
  nome          VARCHAR(150) NOT NULL,
  cidade        VARCHAR(100),
  uf            CHAR(2),
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_unidades_empresa ON unidades(empresa_id);

-- =========================================================
-- 2) PERFIS / MÓDULOS / PERMISSÕES (RBAC dinâmico)
-- =========================================================
-- 4 perfis pré-configurados + suporte a perfis customizados (is_sistema=false)
CREATE TABLE perfis (
  id            SERIAL PRIMARY KEY,
  chave         VARCHAR(40) UNIQUE NOT NULL,   -- 'admin_master','gestor_rh','lider_gestor','colaborador', ou custom
  nome          VARCHAR(100) NOT NULL,
  descricao     TEXT,
  is_sistema    BOOLEAN NOT NULL DEFAULT FALSE, -- perfis de fábrica não podem ser excluídos
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Engine de módulos dinâmicos: cada módulo pode ser ligado/desligado globalmente
CREATE TABLE modulos (
  id            SERIAL PRIMARY KEY,
  chave         VARCHAR(40) UNIQUE NOT NULL,    -- 'dashboard','colaboradores','pesquisas', etc.
  nome          VARCHAR(120) NOT NULL,
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  ordem         INTEGER NOT NULL DEFAULT 0
);

-- Matriz de permissões CRUD por perfil x módulo — é isso que o painel
-- "Configuração de Módulos" (ADM/RH) edita.
CREATE TABLE modulos_permissoes (
  id            SERIAL PRIMARY KEY,
  modulo_id     INTEGER NOT NULL REFERENCES modulos(id) ON DELETE CASCADE,
  perfil_id     INTEGER NOT NULL REFERENCES perfis(id) ON DELETE CASCADE,
  pode_criar    BOOLEAN NOT NULL DEFAULT FALSE,
  pode_ler      BOOLEAN NOT NULL DEFAULT FALSE,
  pode_atualizar BOOLEAN NOT NULL DEFAULT FALSE,
  pode_deletar  BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE(modulo_id, perfil_id)
);

-- Campos customizados que o ADM/RH pode adicionar à ficha do colaborador
-- (engine de módulos, item "criar/renomear campos personalizados")
CREATE TABLE campos_customizados (
  id            SERIAL PRIMARY KEY,
  entidade      VARCHAR(40) NOT NULL DEFAULT 'colaborador',
  chave         VARCHAR(60) NOT NULL,
  rotulo        VARCHAR(120) NOT NULL,
  tipo          VARCHAR(20) NOT NULL DEFAULT 'texto', -- texto|numero|data|selecao|booleano
  opcoes        JSONB,                                  -- para tipo 'selecao'
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  UNIQUE(entidade, chave)
);

-- =========================================================
-- 3) USUÁRIOS (credenciais)
-- =========================================================
CREATE TABLE usuarios (
  id                SERIAL PRIMARY KEY,
  login             VARCHAR(80) UNIQUE NOT NULL,
  email             VARCHAR(150) UNIQUE,
  senha_hash        VARCHAR(100) NOT NULL,      -- bcrypt (60 chars), compatível com pgcrypto crypt()
  perfil_id         INTEGER NOT NULL REFERENCES perfis(id) ON DELETE RESTRICT,
  empresa_escopo_id INTEGER REFERENCES empresas(id), -- NULL = acesso a todo o grupo (admin_master/gestor_rh)
  colaborador_id    INTEGER,                    -- FK adicionada depois que 'colaboradores' existir
  status            VARCHAR(20) NOT NULL DEFAULT 'ativo', -- ativo|bloqueado|inativo
  precisa_trocar_senha BOOLEAN NOT NULL DEFAULT TRUE,
  tentativas_login  INTEGER NOT NULL DEFAULT 0,
  ultimo_login      TIMESTAMPTZ,
  foto_url          TEXT,
  criado_em         TIMESTAMPTZ NOT NULL DEFAULT now(),
  atualizado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_usuarios_perfil ON usuarios(perfil_id);
CREATE INDEX idx_usuarios_empresa ON usuarios(empresa_escopo_id);

-- Tokens de "esqueci minha senha" (o front-end já tem essa tela — RESET_TOKENS)
CREATE TABLE reset_tokens (
  id            SERIAL PRIMARY KEY,
  usuario_id    INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  token         UUID NOT NULL DEFAULT uuid_generate_v4(),
  usado         BOOLEAN NOT NULL DEFAULT FALSE,
  expira_em     TIMESTAMPTZ NOT NULL,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =========================================================
-- 4) COLABORADORES (ficha completa)
-- =========================================================
CREATE TABLE colaboradores (
  id                SERIAL PRIMARY KEY,
  usuario_id        INTEGER REFERENCES usuarios(id) ON DELETE SET NULL,
  empresa_id        INTEGER NOT NULL REFERENCES empresas(id) ON DELETE RESTRICT,
  unidade_id        INTEGER REFERENCES unidades(id) ON DELETE SET NULL,
  gestor_id         INTEGER REFERENCES colaboradores(id) ON DELETE SET NULL, -- líder direto
  nome              VARCHAR(150) NOT NULL,
  cpf               VARCHAR(14) UNIQUE,
  cargo             VARCHAR(120),
  departamento      VARCHAR(120),
  salario           NUMERIC(12,2),
  data_admissao     DATE,
  data_demissao     DATE,
  status            VARCHAR(20) NOT NULL DEFAULT 'ativo', -- ativo|afastado|desligado
  telefone          VARCHAR(20),
  email_pessoal     VARCHAR(150),
  endereco          TEXT,
  foto_url          TEXT,
  campos_extra      JSONB NOT NULL DEFAULT '{}',   -- valores dos campos_customizados
  criado_em         TIMESTAMPTZ NOT NULL DEFAULT now(),
  atualizado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_colab_empresa ON colaboradores(empresa_id);
CREATE INDEX idx_colab_gestor ON colaboradores(gestor_id);
CREATE INDEX idx_colab_usuario ON colaboradores(usuario_id);

ALTER TABLE usuarios
  ADD CONSTRAINT fk_usuarios_colaborador
  FOREIGN KEY (colaborador_id) REFERENCES colaboradores(id) ON DELETE SET NULL;

-- =========================================================
-- 5) ATESTADOS / LICENÇAS
-- =========================================================
CREATE TABLE atestados_licencas (
  id            SERIAL PRIMARY KEY,
  colaborador_id INTEGER NOT NULL REFERENCES colaboradores(id) ON DELETE CASCADE,
  tipo          VARCHAR(40) NOT NULL,   -- atestado|licenca_medica|licenca_maternidade|ferias|...
  data_inicio   DATE NOT NULL,
  data_fim      DATE NOT NULL,
  dias          INTEGER GENERATED ALWAYS AS (data_fim - data_inicio + 1) STORED,
  cid           VARCHAR(10),
  motivo        TEXT,
  arquivo_url   TEXT,
  status        VARCHAR(20) NOT NULL DEFAULT 'pendente', -- pendente|aprovado|recusado
  aprovado_por  INTEGER REFERENCES usuarios(id),
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_atestados_colab ON atestados_licencas(colaborador_id);
CREATE INDEX idx_atestados_status ON atestados_licencas(status);

-- =========================================================
-- 6) PESQUISAS DE CLIMA
-- =========================================================
CREATE TABLE pesquisas_clima (
  id            SERIAL PRIMARY KEY,
  titulo        VARCHAR(200) NOT NULL,
  descricao     TEXT,
  empresa_id    INTEGER REFERENCES empresas(id),  -- NULL = todo o grupo
  anonima       BOOLEAN NOT NULL DEFAULT TRUE,
  data_inicio   DATE NOT NULL,
  data_fim      DATE NOT NULL,
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  criado_por    INTEGER REFERENCES usuarios(id),
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE perguntas_pesquisa (
  id            SERIAL PRIMARY KEY,
  pesquisa_id   INTEGER NOT NULL REFERENCES pesquisas_clima(id) ON DELETE CASCADE,
  texto         TEXT NOT NULL,
  tipo          VARCHAR(20) NOT NULL DEFAULT 'escala_1_5', -- escala_1_5|texto_livre|multipla_escolha
  opcoes        JSONB,
  ordem         INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE respostas_pesquisa (
  id            SERIAL PRIMARY KEY,
  pesquisa_id   INTEGER NOT NULL REFERENCES pesquisas_clima(id) ON DELETE CASCADE,
  pergunta_id   INTEGER NOT NULL REFERENCES perguntas_pesquisa(id) ON DELETE CASCADE,
  -- colaborador_id fica NULL quando a pesquisa é anônima; a coluna existe
  -- apenas para controlar "quem já respondeu" (respondido_por), nunca é
  -- exposta junto do conteúdo da resposta quando anonima=true.
  respondido_por INTEGER REFERENCES colaboradores(id) ON DELETE SET NULL,
  resposta      TEXT NOT NULL,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_respostas_pesquisa ON respostas_pesquisa(pesquisa_id);

-- =========================================================
-- 7) AVALIAÇÕES 9-BOX
-- =========================================================
CREATE TABLE avaliacoes_9box (
  id            SERIAL PRIMARY KEY,
  colaborador_id INTEGER NOT NULL REFERENCES colaboradores(id) ON DELETE CASCADE,
  ciclo         VARCHAR(20) NOT NULL,          -- ex: '2026-S1'
  eixo_desempenho INTEGER NOT NULL CHECK (eixo_desempenho BETWEEN 1 AND 3),
  eixo_potencial  INTEGER NOT NULL CHECK (eixo_potencial BETWEEN 1 AND 3),
  observacoes   TEXT,
  avaliado_por  INTEGER REFERENCES usuarios(id),
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(colaborador_id, ciclo)
);

-- =========================================================
-- 8) AUDITORIA (genérica, via trigger)
-- =========================================================
CREATE TABLE auditoria (
  id            BIGSERIAL PRIMARY KEY,
  usuario_id    INTEGER REFERENCES usuarios(id),
  tabela        VARCHAR(60) NOT NULL,
  registro_id   INTEGER,
  acao          VARCHAR(10) NOT NULL,   -- INSERT|UPDATE|DELETE
  dados_antes   JSONB,
  dados_depois  JSONB,
  criado_em     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_auditoria_tabela ON auditoria(tabela, registro_id);

-- Função genérica de auditoria. app.current_user_id é setado pelo backend
-- em cada conexão via `SET LOCAL app.current_user_id = $1` no início da
-- transação (ver src/config/db.js).
CREATE OR REPLACE FUNCTION fn_auditoria() RETURNS TRIGGER AS $$
DECLARE
  v_usuario_id INTEGER;
BEGIN
  BEGIN
    v_usuario_id := NULLIF(current_setting('app.current_user_id', true), '')::INTEGER;
  EXCEPTION WHEN OTHERS THEN
    v_usuario_id := NULL;
  END;

  IF TG_OP = 'INSERT' THEN
    INSERT INTO auditoria(usuario_id, tabela, registro_id, acao, dados_depois)
    VALUES (v_usuario_id, TG_TABLE_NAME, NEW.id, 'INSERT', to_jsonb(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    INSERT INTO auditoria(usuario_id, tabela, registro_id, acao, dados_antes, dados_depois)
    VALUES (v_usuario_id, TG_TABLE_NAME, NEW.id, 'UPDATE', to_jsonb(OLD), to_jsonb(NEW));
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO auditoria(usuario_id, tabela, registro_id, acao, dados_antes)
    VALUES (v_usuario_id, TG_TABLE_NAME, OLD.id, 'DELETE', to_jsonb(OLD));
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_audit_usuarios AFTER INSERT OR UPDATE OR DELETE ON usuarios
  FOR EACH ROW EXECUTE FUNCTION fn_auditoria();
CREATE TRIGGER trg_audit_colaboradores AFTER INSERT OR UPDATE OR DELETE ON colaboradores
  FOR EACH ROW EXECUTE FUNCTION fn_auditoria();
CREATE TRIGGER trg_audit_atestados AFTER INSERT OR UPDATE OR DELETE ON atestados_licencas
  FOR EACH ROW EXECUTE FUNCTION fn_auditoria();
CREATE TRIGGER trg_audit_permissoes AFTER INSERT OR UPDATE OR DELETE ON modulos_permissoes
  FOR EACH ROW EXECUTE FUNCTION fn_auditoria();

-- trigger simples para manter atualizado_em em dia
CREATE OR REPLACE FUNCTION fn_atualizado_em() RETURNS TRIGGER AS $$
BEGIN NEW.atualizado_em = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_touch_usuarios BEFORE UPDATE ON usuarios
  FOR EACH ROW EXECUTE FUNCTION fn_atualizado_em();
CREATE TRIGGER trg_touch_colaboradores BEFORE UPDATE ON colaboradores
  FOR EACH ROW EXECUTE FUNCTION fn_atualizado_em();

-- =========================================================
-- 9) SEED DATA
-- =========================================================

-- Empresas do grupo (mesmas do front-end: ORDEM_EMPRESAS)
INSERT INTO empresas (chave, nome, cor_tema) VALUES
  ('motos',    'L. Cirne Motos',    '#df2a2a'),
  ('postos',   'L. Cirne Postos',   '#e9ab1e'),
  ('pneus',    'L. Cirne Pneus',    '#f0791f'),
  ('baterias', 'L. Cirne Baterias', '#2f9955');

-- Perfis de fábrica — chaves batem com os 4 perfis pedidos no briefing.
-- 'gestor_rh' cobre o antigo 'admin_rh' do protótipo; 'lider_gestor' cobre
-- o antigo 'gestor_unidade'.
INSERT INTO perfis (chave, nome, descricao, is_sistema) VALUES
  ('admin_master', 'Administrador Master', 'Acesso irrestrito: usuários, permissões, módulos e dados de todo o grupo.', TRUE),
  ('gestor_rh',     'Gestor/RH',            'Acesso total de leitura e escrita em todas as empresas do grupo.', TRUE),
  ('lider_gestor',  'Líder/Gestor de Setor','Acesso restrito aos colaboradores diretamente subordinados.', TRUE),
  ('colaborador',   'Colaborador',          'Acesso exclusivo aos próprios dados.', TRUE);

-- Módulos — mesmas chaves do array MODULOS do front-end atual, para que o
-- front continue funcionando sem precisar renomear nada.
INSERT INTO modulos (chave, nome, ordem) VALUES
  ('dashboard','Dashboard',1), ('colaboradores','Colaboradores',2), ('onboarding','Onboarding',3),
  ('desligamentos','Desligamentos',4), ('treinamentos','Treinamentos',5), ('mapeamento','Mapeamento',6),
  ('pdi','PDI',7), ('pesquisas','Pesquisas de Clima',8), ('sac','SAC',9), ('materiais','Materiais',10),
  ('atestados','Atestados/Licenças',11), ('avaliacoes','Avaliações',12), ('comportamental','Perfil Comportamental',13),
  ('lideranca','Mapa de Liderança',14), ('carreira','Carreira',15), ('executivo','Painel Executivo',16),
  ('relatorio','Relatórios',17), ('alertas','Central de Alertas',18), ('administracao','Configurações',19);

-- admin_master: CRUD completo em tudo
INSERT INTO modulos_permissoes (modulo_id, perfil_id, pode_criar, pode_ler, pode_atualizar, pode_deletar)
SELECT m.id, p.id, TRUE, TRUE, TRUE, TRUE FROM modulos m, perfis p WHERE p.chave = 'admin_master';

-- gestor_rh: CRUD completo em tudo, exceto administração (só ADM Master mexe em permissões)
INSERT INTO modulos_permissoes (modulo_id, perfil_id, pode_criar, pode_ler, pode_atualizar, pode_deletar)
SELECT m.id, p.id, TRUE, TRUE, TRUE, TRUE FROM modulos m, perfis p
WHERE p.chave = 'gestor_rh' AND m.chave <> 'administracao';
INSERT INTO modulos_permissoes (modulo_id, perfil_id, pode_criar, pode_ler, pode_atualizar, pode_deletar)
SELECT m.id, p.id, FALSE, TRUE, FALSE, FALSE FROM modulos m, perfis p
WHERE p.chave = 'gestor_rh' AND m.chave = 'administracao';

-- lider_gestor: leitura/edição só nos módulos operacionais de equipe (espelha PERFIS.gestor_unidade do front)
INSERT INTO modulos_permissoes (modulo_id, perfil_id, pode_criar, pode_ler, pode_atualizar, pode_deletar)
SELECT m.id, p.id,
  m.chave IN ('colaboradores','onboarding','mapeamento','treinamentos','pdi','avaliacoes','atestados','desligamentos'),
  m.chave IN ('dashboard','colaboradores','onboarding','mapeamento','treinamentos','pdi','pesquisas','avaliacoes','carreira','comportamental','lideranca','materiais','atestados','desligamentos'),
  m.chave IN ('colaboradores','onboarding','mapeamento','treinamentos','pdi','avaliacoes','atestados','desligamentos'),
  FALSE
FROM modulos m, perfis p WHERE p.chave = 'lider_gestor';

-- colaborador: só os módulos de autoatendimento (espelha PERFIS.colaborador do front)
INSERT INTO modulos_permissoes (modulo_id, perfil_id, pode_criar, pode_ler, pode_atualizar, pode_deletar)
SELECT m.id, p.id,
  m.chave IN ('sac'),
  m.chave IN ('treinamentos','pdi','pesquisas','sac','materiais'),
  m.chave IN ('sac'),
  FALSE
FROM modulos m, perfis p WHERE p.chave = 'colaborador';

-- Usuário Administrador Master inicial.
-- SEGURANÇA: nasce BLOQUEADO. A senha abaixo é pública (está no repositório) e só serve
-- para o schema ter um hash válido. Quem libera o acesso é `npm run bootstrap-admin`,
-- que define uma senha aleatória e ativa o usuário. Nunca ative sem trocar a senha.
INSERT INTO usuarios (login, email, senha_hash, perfil_id, status, precisa_trocar_senha)
SELECT 'admin.master', 'ti@grupolcirne.com.br',
       crypt('TrocarSenha#2026', gen_salt('bf', 10)),
       p.id, 'bloqueado', TRUE
FROM perfis p WHERE p.chave = 'admin_master';
