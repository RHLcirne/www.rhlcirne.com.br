require('dotenv').config();
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const PROD = process.env.NODE_ENV === 'production';

// --- Falha rápido em produção se a configuração for insegura ---
if (PROD) {
  const problemas = [];
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32 || /troque|senha|secret|exemplo/i.test(process.env.JWT_SECRET)) problemas.push('JWT_SECRET ausente, curto (<32) ou de exemplo');
  if (!process.env.DATABASE_URL) problemas.push('DATABASE_URL ausente');
  if (problemas.length) { console.error('CONFIGURAÇÃO INSEGURA:', problemas.join('; ')); process.exit(1); }
}

const { errorHandler } = require('./middleware/errorHandler');
const authRoutes = require('./routes/auth.routes');
const usuariosRoutes = require('./routes/usuarios.routes');
const colaboradoresRoutes = require('./routes/colaboradores.routes');
const modulosRoutes = require('./routes/modulos.routes');
const atestadosRoutes = require('./routes/atestados.routes');
const pesquisasRoutes = require('./routes/pesquisas.routes');
const pdiRoutes = require('./routes/pdi.routes');
const liderancaMotorRoutes = require('./routes/liderancaMotor.routes');
const empresasRoutes = require('./routes/empresas.routes');

const app = express();
app.disable('x-powered-by');
// Atrás do Caddy/Nginx: sem isto o rate limit enxergaria todos como o mesmo IP (o do proxy).
app.set('trust proxy', Number(process.env.TRUST_PROXY_HOPS || 1));

app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'", "'unsafe-inline'"],
    imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"],
    baseUri: ["'self'"], formAction: ["'self'"],
    upgradeInsecureRequests: PROD ? [] : null,
  } },
  hsts: PROD ? { maxAge: 31536000, includeSubDomains: true } : false,
}));
// Portal e API na mesma origem => CORS só é necessário se houver outro domínio de front.
const origens = (process.env.CORS_ORIGIN || '').split(',').filter(Boolean);
if (origens.length) app.use(cors({ origin: origens, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan(PROD ? 'combined' : 'dev'));

app.use('/api', rateLimit({ windowMs: 60 * 1000, max: 300, standardHeaders: true, legacyHeaders: false }));
app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRoutes);
app.use('/api/usuarios', usuariosRoutes);
app.use('/api', colaboradoresRoutes);
app.use('/api', modulosRoutes);
app.use('/api', atestadosRoutes);
app.use('/api', pesquisasRoutes);
app.use('/api', pdiRoutes);
app.use('/api', liderancaMotorRoutes);
app.use('/api', empresasRoutes);
app.use('/api', (req, res) => res.status(404).json({ erro: 'Rota não encontrada.' }));

// Portal (arquivos estáticos). Nada de dados sensíveis aqui: tudo passa pela API autenticada.
const FRONT = process.env.FRONTEND_DIR || path.join(__dirname, '..', '..', 'frontend');
app.use(express.static(FRONT, { index: 'index.html', maxAge: PROD ? '1h' : 0, dotfiles: 'deny' }));

app.use(errorHandler);
const PORT = process.env.PORT || 3333;
app.listen(PORT, () => console.log(`Gestão de Pessoas · Grupo L. Cirne na porta ${PORT} (${PROD ? 'produção' : 'desenvolvimento'})`));
