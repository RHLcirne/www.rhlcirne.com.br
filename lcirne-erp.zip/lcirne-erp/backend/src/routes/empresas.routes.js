const { Router } = require('express');
const { autenticar } = require('../middleware/auth');
const { exigirPerfil } = require('../middleware/rbac');
const { query } = require('../config/db');

const router = Router();
// Lista de empresas/unidades para os formulários do RH. gestor_rh com escopo fixo só vê a sua.
router.get('/empresas', autenticar, exigirPerfil('admin_master', 'gestor_rh'), async (req, res, next) => {
  try {
    const p = []; let w = 'e.ativo';
    if (req.user.empresaEscopoId) { p.push(req.user.empresaEscopoId); w += ` AND e.id = $${p.length}`; }
    const { rows } = await query(`SELECT e.id, e.chave, e.nome FROM empresas e WHERE ${w} ORDER BY e.nome`, p);
    res.json(rows);
  } catch (err) { next(err); }
});
module.exports = router;
