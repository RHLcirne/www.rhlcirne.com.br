const { Router } = require('express');
const { autenticar } = require('../middleware/auth');
const { exigirPermissaoModulo } = require('../middleware/rbac');
const ctrl = require('../controllers/pesquisas.controller');

const router = Router();
router.use(autenticar, exigirPermissaoModulo('pesquisas', 'ler'));

router.get('/pesquisas', ctrl.listarAtivas);
router.get('/pesquisas/:id/perguntas', ctrl.perguntas);
router.post('/pesquisas/:id/respostas', ctrl.responder);

// Criar pesquisa e ver resultados agregados exigem permissão de escrita
router.post('/pesquisas', exigirPermissaoModulo('pesquisas', 'criar'), ctrl.criarPesquisa);
router.get('/pesquisas/:id/resultados', exigirPermissaoModulo('pesquisas', 'atualizar'), ctrl.resultados);

module.exports = router;
