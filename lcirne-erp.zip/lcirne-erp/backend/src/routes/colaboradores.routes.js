const { Router } = require('express');
const { autenticar } = require('../middleware/auth');
const { exigirPermissaoModulo } = require('../middleware/rbac');
const ctrl = require('../controllers/colaboradores.controller');

const router = Router();
router.use(autenticar);

// Endpoint de autoatendimento — disponível para QUALQUER perfil logado,
// pois cada um só enxerga o próprio colaboradorId (garantido no controller).
// Corresponde ao endpoint pedido no briefing: /api/colaborador/meus-dados
router.get('/colaborador/meus-dados', ctrl.meusDados);

// Listagem/ficha geral — exige permissão de leitura no módulo 'colaboradores'.
// Colaborador comum não tem essa permissão na matriz padrão (ver seed),
// então já cai 403 aqui antes mesmo do controller reforçar a regra.
router.get('/colaboradores', exigirPermissaoModulo('colaboradores', 'ler'), ctrl.listar);
router.get('/colaboradores/:id', exigirPermissaoModulo('colaboradores', 'ler'), ctrl.buscarPorId);
router.post('/colaboradores', exigirPermissaoModulo('colaboradores', 'criar'), ctrl.criar);
router.put('/colaboradores/:id', exigirPermissaoModulo('colaboradores', 'atualizar'), ctrl.atualizar);

module.exports = router;
