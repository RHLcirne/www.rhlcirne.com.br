const { Router } = require('express');
const { autenticar } = require('../middleware/auth');
const { exigirPermissaoModulo } = require('../middleware/rbac');
const ctrl = require('../controllers/pdi.controller');

const router = Router();
router.use(autenticar, exigirPermissaoModulo('pdi', 'ler'));

router.get('/pdi', ctrl.listar);
router.post('/pdi', exigirPermissaoModulo('pdi', 'criar'), ctrl.criar);
router.put('/pdi/:id', exigirPermissaoModulo('pdi', 'atualizar'), ctrl.atualizar);

module.exports = router;
