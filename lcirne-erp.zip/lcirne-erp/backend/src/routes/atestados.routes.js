const { Router } = require('express');
const { autenticar } = require('../middleware/auth');
const { exigirPermissaoModulo } = require('../middleware/rbac');
const ctrl = require('../controllers/atestados.controller');

const router = Router();
router.use(autenticar);

router.get('/atestados', exigirPermissaoModulo('atestados', 'ler'), ctrl.listar);
router.post('/atestados', exigirPermissaoModulo('atestados', 'criar'), ctrl.criar);
router.patch('/atestados/:id/decisao', exigirPermissaoModulo('atestados', 'atualizar'), ctrl.decidir);

module.exports = router;
