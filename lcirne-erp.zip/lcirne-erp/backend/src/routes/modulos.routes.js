const { Router } = require('express');
const { autenticar } = require('../middleware/auth');
const { exigirPerfil } = require('../middleware/rbac');
const ctrl = require('../controllers/modulos.controller');

const router = Router();

// Qualquer usuário autenticado pode LER quais módulos estão ativos (o
// front-end usa isso para montar o menu lateral dinamicamente).
router.get('/modulos', autenticar, ctrl.listar);

// Só admin_master edita a engine de módulos/permissões — é o painel mais
// sensível do sistema (controla o que todo mundo mais pode fazer).
router.use('/modulos', autenticar, exigirPerfil('admin_master'));
router.patch('/modulos/:id/ativo', ctrl.alternarAtivo);
router.get('/modulos/permissoes', ctrl.matrizPermissoes);
router.patch('/modulos/permissoes/:id', ctrl.atualizarPermissao);
router.get('/modulos/campos-customizados', ctrl.listarCamposCustom);
router.post('/modulos/campos-customizados', ctrl.criarCampoCustom);

module.exports = router;
