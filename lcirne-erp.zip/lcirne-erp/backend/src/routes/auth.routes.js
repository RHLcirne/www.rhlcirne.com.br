const { Router } = require('express');
const rateLimit = require('express-rate-limit');
const { autenticar } = require('../middleware/auth');
const ctrl = require('../controllers/auth.controller');

const router = Router();

// Limita força-bruta de login independentemente do bloqueio por tentativas
// (que é por conta; este é por IP).
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 });

router.post('/login', loginLimiter, ctrl.login);
router.post('/esqueci-senha', loginLimiter, ctrl.solicitarReset);
router.post('/redefinir-senha', ctrl.confirmarReset);
router.post('/trocar-senha', autenticar, ctrl.trocarSenha);

module.exports = router;
