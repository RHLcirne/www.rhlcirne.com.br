const { Router } = require('express');
const { autenticar } = require('../middleware/auth');
const { exigirPerfil, exigirPermissaoModulo } = require('../middleware/rbac');
const c = require('../controllers/liderancaMotor.controller');

// Motor de liderança com banco de questões editável e pegadinhas.
const router = Router();
router.use('/lideranca', autenticar);

const ler = exigirPermissaoModulo('lideranca', 'ler');
const atualizar = exigirPermissaoModulo('lideranca', 'atualizar');
const soRH = exigirPerfil('admin_master', 'gestor_rh');

// --- líder / aplicação ---
router.get('/lideranca/questionario', ler, c.questionario);
router.post('/lideranca/mapas', ler, c.aplicarMapa);
router.get('/lideranca/meu-mapa', ler, c.meuMapa);

// --- gestão de mapas e planos ---
router.get('/lideranca/mapas', ler, c.listarMapas);
router.get('/lideranca/mapas/:id', ler, c.detalheMapa);
router.get('/lideranca/consolidado', soRH, ler, c.consolidado);
router.put('/lideranca/planos/:mapaId', soRH, atualizar, c.editarPlano);
router.post('/lideranca/planos/:mapaId/regerar', soRH, atualizar, c.regerarPlano);
router.post('/lideranca/planos/:mapaId/enviar-pdi', soRH, atualizar, exigirPermissaoModulo('pdi', 'criar'), c.enviarPdi);

// --- painel do RH: banco de questões, regras do plano, parâmetros ---
router.get('/lideranca/admin/banco', soRH, atualizar, c.bancoCompleto);
router.post('/lideranca/admin/questoes', soRH, atualizar, c.criarQuestao);
router.put('/lideranca/admin/questoes/:id', soRH, atualizar, c.atualizarQuestao);
router.patch('/lideranca/admin/questoes/:id/ativo', soRH, atualizar, c.alternarQuestao);
router.delete('/lideranca/admin/questoes/:id', soRH, atualizar, c.excluirQuestao);
router.get('/lideranca/admin/regras', soRH, atualizar, c.listarRegras);
router.post('/lideranca/admin/regras', soRH, atualizar, c.salvarRegra);
router.put('/lideranca/admin/regras/:id', soRH, atualizar, c.salvarRegra);
router.delete('/lideranca/admin/regras/:id', soRH, atualizar, c.excluirRegra);
router.put('/lideranca/admin/config', soRH, atualizar, c.salvarConfig);

module.exports = router;
