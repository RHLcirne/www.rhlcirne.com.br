const { Router } = require('express');
const { autenticar } = require('../middleware/auth');
const { exigirPerfil } = require('../middleware/rbac');
const ctrl = require('../controllers/usuarios.controller');

const router = Router();

// Toda a tela de gestão de credenciais é exclusiva de admin_master/gestor_rh,
// conforme requisito 1 do briefing ("tela exclusiva para cadastrar, editar,
// bloquear e redefinir senhas de qualquer colaborador").
router.use(autenticar, exigirPerfil('admin_master', 'gestor_rh'));

router.get('/', ctrl.listar);
router.post('/', ctrl.criar);
router.put('/:id', ctrl.atualizar);
router.patch('/:id/status', ctrl.alterarStatus);
router.post('/:id/redefinir-senha', ctrl.redefinirSenha);

module.exports = router;
