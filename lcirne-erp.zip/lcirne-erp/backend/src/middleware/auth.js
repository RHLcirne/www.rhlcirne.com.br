const jwt = require('jsonwebtoken');
const { query } = require('../config/db');

// Exige um Bearer token válido. Em caso de sucesso, popula req.user com:
//   { id, login, perfilId, perfilChave, empresaEscopoId, colaboradorId }
// Também confirma no banco que o usuário ainda está ativo — isso garante
// que bloquear alguém no painel de RH derruba a sessão dele imediatamente,
// mesmo que o token JWT ainda não tenha expirado.
async function autenticar(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ erro: 'Token de autenticação ausente.' });
  }

  let payload;
  try {
    payload = jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    return res.status(401).json({ erro: 'Token inválido ou expirado.' });
  }

  try {
    const { rows } = await query(
      `SELECT u.id, u.login, u.status, u.colaborador_id, u.empresa_escopo_id, u.precisa_trocar_senha,
              p.id AS perfil_id, p.chave AS perfil_chave
       FROM usuarios u JOIN perfis p ON p.id = u.perfil_id
       WHERE u.id = $1`,
      [payload.sub]
    );
    const usuario = rows[0];
    if (!usuario || usuario.status !== 'ativo') {
      return res.status(401).json({ erro: 'Sessão inválida. Faça login novamente.' });
    }

    // Senha temporária (criada/redefinida pelo RH ou bootstrap): enquanto a troca estiver pendente,
    // a ÚNICA rota permitida é a de trocar a senha. Sem isto, a exigência valeria só na tela,
    // e quem chamasse a API direto poderia usar a senha temporária indefinidamente.
    if (usuario.precisa_trocar_senha && !req.originalUrl.split('?')[0].endsWith('/auth/trocar-senha')) {
      return res.status(403).json({ erro: 'Troque a senha temporária para continuar.', codigo: 'TROCA_SENHA_OBRIGATORIA' });
    }

    req.user = {
      id: usuario.id,
      login: usuario.login,
      perfilId: usuario.perfil_id,
      perfilChave: usuario.perfil_chave,
      empresaEscopoId: usuario.empresa_escopo_id,
      colaboradorId: usuario.colaborador_id,
    };
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { autenticar };
