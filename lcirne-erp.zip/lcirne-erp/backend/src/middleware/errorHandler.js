// Handler central: qualquer next(err) nas rotas cai aqui.
// Evita vazar stack trace / detalhes internos do banco para o cliente.
function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  console.error(err);

  if (err.code === '23505') { // unique_violation do Postgres
    return res.status(409).json({ erro: 'Já existe um registro com esses dados (violação de unicidade).' });
  }
  if (err.code === '23503') { // foreign_key_violation
    return res.status(409).json({ erro: 'Operação inválida: referência a um registro inexistente.' });
  }

  res.status(err.status || 500).json({
    erro: err.expose ? err.message : 'Erro interno do servidor.',
  });
}

module.exports = { errorHandler };
