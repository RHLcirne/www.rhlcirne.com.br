const { query } = require('../config/db');

// Bloqueia por chave de perfil, para rotas que só um papel específico
// pode acessar (ex: gestão de usuários é só admin_master / gestor_rh).
function exigirPerfil(...perfisPermitidos) {
  return (req, res, next) => {
    if (!req.user || !perfisPermitidos.includes(req.user.perfilChave)) {
      return res.status(403).json({ erro: 'Você não tem permissão para acessar este recurso.' });
    }
    next();
  };
}

// Checagem granular via engine de módulos: consulta modulos_permissoes
// para o (perfil, módulo) do usuário logado e a ação pedida (criar|ler|
// atualizar|deletar). Isso é o que faz o painel "Configuração de Módulos"
// (ativar/desativar módulo, editar CRUD por perfil) ter efeito real na API,
// e não só cosmético no front-end.
function exigirPermissaoModulo(chaveModulo, acao) {
  const coluna = {
    criar: 'pode_criar',
    ler: 'pode_ler',
    atualizar: 'pode_atualizar',
    deletar: 'pode_deletar',
  }[acao];
  if (!coluna) throw new Error(`Ação de permissão desconhecida: ${acao}`);

  return async (req, res, next) => {
    try {
      const { rows } = await query(
        `SELECT mp.${coluna} AS permitido, m.ativo AS modulo_ativo
         FROM modulos_permissoes mp
         JOIN modulos m ON m.id = mp.modulo_id
         WHERE m.chave = $1 AND mp.perfil_id = $2`,
        [chaveModulo, req.user.perfilId]
      );
      const linha = rows[0];
      if (!linha || !linha.modulo_ativo) {
        return res.status(403).json({ erro: 'Este módulo está desativado ou não existe.' });
      }
      if (!linha.permitido) {
        return res.status(403).json({ erro: 'Seu perfil não tem permissão para esta ação neste módulo.' });
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}

module.exports = { exigirPerfil, exigirPermissaoModulo };
