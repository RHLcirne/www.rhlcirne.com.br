// Funções puras (sem acesso a banco) — fáceis de testar e de auditar.

const arred = (n) => Math.round(n);

// respostas: [{ dimChave, parte, tipo, questaoId, parId, pontos, vitrine }]
// dims:      [{ id, chave, nome }]
// faixas:    [{ chave, rotulo, pct_min, cor }]   cfg: { limiar_gap, limiar_vitrine }
function apurar(respostas, dims, faixas, cfg) {
  const dimensoes = dims.map((d) => {
    const rs = respostas.filter((r) => r.dimChave === d.chave);
    const soma = (lista) => lista.reduce((a, r) => a + r.pontos, 0);
    const pct = (lista) => (lista.length ? (soma(lista) / (lista.length * 5)) * 100 : null);
    const p1 = pct(rs.filter((r) => r.parte === 1));
    const p2 = pct(rs.filter((r) => r.parte === 2));
    return {
      dimensaoId: d.id, chave: d.chave, nome: d.nome,
      bruto: soma(rs), max: rs.length * 5,
      pct: rs.length ? arred((soma(rs) / (rs.length * 5)) * 100) : null,
      p1: p1 === null ? null : arred(p1), p2: p2 === null ? null : arred(p2),
      gap: p1 !== null && p2 !== null ? Math.abs(p1 - p2) : null,
    };
  });

  const comDados = dimensoes.filter((d) => d.max > 0);
  const totalBruto = comDados.reduce((a, d) => a + d.bruto, 0);
  const totalMax = comDados.reduce((a, d) => a + d.max, 0);
  const geralPct = totalMax ? arred((totalBruto / totalMax) * 100) : 0;
  const faixa = [...faixas].sort((a, b) => b.pct_min - a.pct_min).find((f) => geralPct >= f.pct_min)
    || faixas[faixas.length - 1];

  const gaps = comDados.map((d) => d.gap).filter((g) => g !== null);
  const gapMedio = gaps.length ? Math.round((gaps.reduce((a, b) => a + b, 0) / gaps.length) * 10) / 10 : null;

  // Pegadinhas: quantas vezes caiu na opção "de vitrine"
  const peg = respostas.filter((r) => r.tipo === 'pegadinha');
  const indiceVitrine = peg.length ? arred((peg.filter((r) => r.vitrine).length / peg.length) * 100) : null;

  // Pares espelho: mesma situação-tipo respondida de forma muito diferente
  const porQ = new Map(respostas.map((r) => [r.questaoId, r]));
  const paresDivergentes = [];
  for (const r of peg) {
    const par = r.parId && porQ.get(r.parId);
    if (par && par.pontos - r.pontos >= 3) {
      paresDivergentes.push({ dimChave: r.dimChave, questaoId: r.questaoId, parId: r.parId, pontosPar: par.pontos, pontosPegadinha: r.pontos });
    }
  }

  const alertas = [];
  if (gapMedio !== null && gapMedio >= cfg.limiar_gap) alertas.push('inconsistencia_partes');
  if (indiceVitrine !== null && indiceVitrine >= cfg.limiar_vitrine) alertas.push('respostas_de_vitrine');
  if (paresDivergentes.length >= 2) alertas.push('pares_divergentes');

  let confiabilidade = 'alta';
  if (alertas.length === 1) confiabilidade = 'media';
  if (alertas.length >= 2 || alertas.includes('respostas_de_vitrine')) confiabilidade = 'baixa';

  return { geralPct, faixaChave: faixa.chave, faixaRotulo: faixa.rotulo, gapMedio, indiceVitrine,
           paresDivergentes, alertas, confiabilidade, dimensoes };
}

// regras: linhas de lid_regras_plano (ativas). Devolve ações ordenadas por prioridade.
function gerarPlano(resultado, regras, cfg) {
  const acoes = [];
  const add = (r, pct) => acoes.push({
    regraId: r.id, dimensaoId: r.dimensao_id || null, titulo: r.titulo, descricao: r.descricao,
    tipoAcao: r.tipo_acao, prazoDias: r.prazo_dias, prioridade: r.prioridade, _pct: pct ?? 101,
  });

  const fracas = resultado.dimensoes
    .filter((d) => d.pct !== null && d.pct < cfg.pct_dimensao_reforco)
    .sort((a, b) => a.pct - b.pct)
    .slice(0, cfg.max_dimensoes_plano);

  for (const d of fracas) {
    regras.filter((r) => r.gatilho === 'dimensao' && r.dimensao_id === d.dimensaoId
      && d.pct >= r.pct_min && d.pct <= r.pct_max).forEach((r) => add(r, d.pct));
  }
  if (resultado.alertas.includes('inconsistencia_partes') || resultado.alertas.includes('pares_divergentes')) {
    regras.filter((r) => r.gatilho === 'consistencia').forEach((r) => add(r, 0));
  }
  if (resultado.alertas.includes('respostas_de_vitrine')) {
    regras.filter((r) => r.gatilho === 'vitrine').forEach((r) => add(r, 0));
  }
  regras.filter((r) => r.gatilho === 'faixa' && r.faixa_chave === resultado.faixaChave).forEach((r) => add(r, 50));

  return acoes.sort((a, b) => a.prioridade - b.prioridade || a._pct - b._pct)
              .map(({ _pct, ...resto }) => resto);
}

// Validação de uma questão enviada pelo RH. Devolve lista de erros (vazia = ok).
function validarQuestao(b) {
  const erros = [];
  if (!b.texto || b.texto.trim().length < 20) erros.push('O enunciado precisa ter ao menos 20 caracteres.');
  if (![1, 2].includes(Number(b.parte))) erros.push('A parte deve ser 1 ou 2.');
  if (!['normal', 'pegadinha'].includes(b.tipo)) erros.push('Tipo inválido.');
  const ops = Array.isArray(b.opcoes) ? b.opcoes : [];
  if (ops.length < 3 || ops.length > 6) erros.push('Use de 3 a 6 opções.');
  const textos = ops.map((o) => (o.texto || '').trim().toLowerCase());
  if (textos.some((t) => t.length < 5)) erros.push('Toda opção precisa de texto (mínimo 5 caracteres).');
  if (new Set(textos).size !== textos.length) erros.push('Há opções repetidas.');
  if (ops.some((o) => !Number.isInteger(o.pontos) || o.pontos < 1 || o.pontos > 5)) erros.push('Os pontos devem ser inteiros de 1 a 5.');
  const pts = ops.map((o) => o.pontos);
  if (pts.length && Math.max(...pts) < 4) erros.push('Deve existir ao menos uma opção com 4 ou 5 pontos (a melhor resposta).');
  if (pts.length && Math.max(...pts) - Math.min(...pts) < 2) erros.push('As opções precisam ter diferença de pelo menos 2 pontos entre a melhor e a pior.');
  const vit = ops.filter((o) => o.vitrine);
  if (b.tipo === 'normal' && vit.length) erros.push('Só questões do tipo "pegadinha" podem ter opção de vitrine.');
  if (b.tipo === 'pegadinha') {
    if (!vit.length) erros.push('Uma pegadinha precisa de ao menos uma opção de vitrine (que soa correta, mas é a errada).');
    if (vit.some((o) => o.pontos > 3)) erros.push('A opção de vitrine deve valer no máximo 3 pontos.');
    if (!ops.some((o) => !o.vitrine && o.pontos === 5)) erros.push('A melhor resposta (5 pontos) não pode ser a de vitrine.');
  }
  return erros;
}

// Avisos de cobertura do banco: para medir consistência, cada dimensão ativa
// precisa de questões nas duas partes; para detectar vitrine, ao menos 1 pegadinha.
function avisosCobertura(questoesAtivas, dims) {
  const av = [];
  for (const d of dims.filter((x) => x.ativo)) {
    const qs = questoesAtivas.filter((q) => q.dimensao_id === d.id);
    if (!qs.some((q) => q.parte === 1)) av.push(`${d.chave}: sem questões na parte 1.`);
    if (!qs.some((q) => q.parte === 2)) av.push(`${d.chave}: sem questões na parte 2 (consistência não poderá ser medida).`);
    if (!qs.some((q) => q.tipo === 'pegadinha')) av.push(`${d.chave}: nenhuma pegadinha ativa.`);
    if (qs.length < 4) av.push(`${d.chave}: menos de 4 questões — resultado da dimensão fica pouco confiável.`);
  }
  return av;
}

module.exports = { apurar, gerarPlano, validarQuestao, avisosCobertura };
