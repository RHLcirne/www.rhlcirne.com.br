const { query, withUserTransaction } = require('../config/db');
const S = require('../services/lideranca.service');

const ehRH = (u) => ['admin_master', 'gestor_rh'].includes(u.perfilChave);
const erro = (status, msg) => Object.assign(new Error(msg), { status, expose: true });

async function carregarMotor() {
  const [dims, faixas, regras, cfgRows] = await Promise.all([
    query('SELECT * FROM lid_dimensoes ORDER BY ordem'),
    query('SELECT * FROM lid_faixas ORDER BY pct_min DESC'),
    query('SELECT * FROM lid_regras_plano WHERE ativo'),
    query('SELECT chave, valor FROM lid_config'),
  ]);
  const cfg = Object.fromEntries(cfgRows.rows.map((r) => [r.chave, Number(r.valor)]));
  return { dims: dims.rows, faixas: faixas.rows, regras: regras.rows, cfg };
}

async function podeVerColaborador(user, colaboradorId) {
  if (user.perfilChave === 'admin_master') return true;
  if (colaboradorId === user.colaboradorId) return true;
  const { rows } = await query('SELECT empresa_id, gestor_id FROM colaboradores WHERE id = $1', [colaboradorId]);
  const c = rows[0];
  if (!c) return false;
  if (user.perfilChave === 'gestor_rh') return !user.empresaEscopoId || c.empresa_id === user.empresaEscopoId;
  if (user.perfilChave === 'lider_gestor') return c.gestor_id === user.colaboradorId;
  return false;
}

// Confiabilidade, índice de vitrine e pares divergentes são ferramentas do RH:
// não vão para o líder avaliado (mostrar entregaria a "chave" das pegadinhas).
function visaoMapa(m, user) {
  const r = m.resultado;
  const base = {
    id: m.id, colaboradorId: m.colaborador_id, colaboradorNome: m.colaborador_nome, criadoEm: m.criado_em,
    geralPct: m.geral_pct, faixaChave: m.faixa_chave, autoaplicacao: m.autoaplicacao,
    dimensoes: r.dimensoes.map((d) => ({ chave: d.chave, nome: d.nome, pct: d.pct })),
  };
  if (ehRH(user)) {
    return { ...base, gapMedio: m.gap_medio, indiceVitrine: m.indice_vitrine, confiabilidade: m.confiabilidade,
             alertas: r.alertas, paresDivergentes: r.paresDivergentes, dimensoesDetalhe: r.dimensoes };
  }
  return base;
}

/* =========================  LÍDER / APLICAÇÃO  ========================= */

function embaralhar(a) {
  const x = [...a];
  for (let i = x.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [x[i], x[j]] = [x[j], x[i]]; }
  return x;
}

// Entrega só id + texto. Nunca pontos, vitrine, tipo, dimensão ou par.
async function questionario(req, res, next) {
  try {
    const qs = await query(`SELECT q.id, q.texto FROM lid_questoes q JOIN lid_dimensoes d ON d.id = q.dimensao_id WHERE q.ativo AND d.ativo`);
    const ops = await query('SELECT o.id, o.questao_id, o.texto FROM lid_opcoes o WHERE o.questao_id = ANY($1)', [qs.rows.map((q) => q.id)]);
    res.json(embaralhar(qs.rows).map((q) => ({
      id: q.id, texto: q.texto,
      opcoes: embaralhar(ops.rows.filter((o) => o.questao_id === q.id)).map((o) => ({ id: o.id, texto: o.texto })),
    })));
  } catch (err) { next(err); }
}

async function gravarAcoes(c, planoId, acoes) {
  for (const a of acoes) {
    await c.query(`INSERT INTO lid_plano_acoes (plano_id, regra_id, dimensao_id, titulo, descricao, tipo_acao, prazo_dias, prioridade)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`, [planoId, a.regraId, a.dimensaoId, a.titulo, a.descricao, a.tipoAcao, a.prazoDias, a.prioridade]);
  }
}

async function aplicarMapa(req, res, next) {
  try {
    const alvo = Number(req.body.colaboradorId) || req.user.colaboradorId;
    if (!alvo) throw erro(400, 'Usuário sem ficha de colaborador vinculada.');
    const auto = alvo === req.user.colaboradorId;
    if (!auto && (req.user.perfilChave === 'colaborador' || !(await podeVerColaborador(req.user, alvo)))) {
      throw erro(403, 'Você não pode aplicar o mapa para este colaborador.');
    }

    const motor = await carregarMotor();
    const qRows = (await query(`SELECT q.id, q.parte, q.tipo, q.par_id, d.chave AS dim_chave FROM lid_questoes q
                                JOIN lid_dimensoes d ON d.id = q.dimensao_id WHERE q.ativo AND d.ativo`)).rows;
    const oRows = (await query('SELECT id, questao_id, pontos, vitrine FROM lid_opcoes WHERE questao_id = ANY($1)', [qRows.map((q) => q.id)])).rows;
    const qMap = new Map(qRows.map((q) => [q.id, q]));
    const oMap = new Map(oRows.map((o) => [o.id, o]));

    const vistas = new Set();
    const resp = (Array.isArray(req.body.respostas) ? req.body.respostas : []).map((r) => {
      const q = qMap.get(Number(r.questaoId));
      const o = oMap.get(Number(r.opcaoId));
      if (!q || !o || o.questao_id !== q.id) throw erro(400, 'Resposta inválida: questão ou opção não reconhecida.');
      if (vistas.has(q.id)) throw erro(400, 'Questão respondida mais de uma vez.');
      vistas.add(q.id);
      return { dimChave: q.dim_chave, parte: q.parte, tipo: q.tipo, questaoId: q.id, parId: q.par_id, opcaoId: o.id, pontos: o.pontos, vitrine: o.vitrine };
    });
    if (vistas.size !== qRows.length) throw erro(400, `Responda todas as questões (${vistas.size}/${qRows.length}).`);

    const resultado = S.apurar(resp, motor.dims.filter((d) => d.ativo), motor.faixas, motor.cfg);
    const acoes = S.gerarPlano(resultado, motor.regras, motor.cfg);

    const mapaId = await withUserTransaction(req.user.id, async (c) => {
      const { rows } = await c.query(
        `INSERT INTO lid_mapas (colaborador_id, aplicado_por, autoaplicacao, geral_pct, faixa_chave, gap_medio, indice_vitrine, confiabilidade, resultado)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
        [alvo, req.user.id, auto, resultado.geralPct, resultado.faixaChave, resultado.gapMedio, resultado.indiceVitrine, resultado.confiabilidade, JSON.stringify(resultado)]);
      const id = rows[0].id;
      for (const r of resp) {
        await c.query('INSERT INTO lid_respostas (mapa_id, questao_id, opcao_id, pontos, vitrine) VALUES ($1,$2,$3,$4,$5)', [id, r.questaoId, r.opcaoId, r.pontos, r.vitrine]);
      }
      const p = await c.query('INSERT INTO lid_planos (mapa_id) VALUES ($1) RETURNING id', [id]);
      await gravarAcoes(c, p.rows[0].id, acoes);
      return id;
    });

    const { rows } = await query('SELECT m.*, c.nome AS colaborador_nome FROM lid_mapas m JOIN colaboradores c ON c.id = m.colaborador_id WHERE m.id = $1', [mapaId]);
    res.status(201).json(visaoMapa(rows[0], req.user));
  } catch (err) { next(err); }
}

async function planoDoMapa(mapaId, user) {
  const plano = (await query('SELECT * FROM lid_planos WHERE mapa_id = $1', [mapaId])).rows[0];
  if (!plano) return null;
  // O líder só enxerga o plano depois que o RH revisou e aprovou.
  if (!ehRH(user) && plano.status === 'rascunho') return { status: 'em_revisao', acoes: [] };
  const acoes = await query(
    `SELECT a.*, d.chave AS dim_chave FROM lid_plano_acoes a LEFT JOIN lid_dimensoes d ON d.id = a.dimensao_id
     WHERE a.plano_id = $1 ${ehRH(user) ? '' : 'AND a.incluir'} ORDER BY a.prioridade, a.id`, [plano.id]);
  return { id: plano.id, status: plano.status, acoes: acoes.rows };
}

async function meuMapa(req, res, next) {
  try {
    if (!req.user.colaboradorId) throw erro(404, 'Sem ficha de colaborador.');
    const { rows } = await query(
      `SELECT m.*, c.nome AS colaborador_nome FROM lid_mapas m JOIN colaboradores c ON c.id = m.colaborador_id
       WHERE m.colaborador_id = $1 ORDER BY m.criado_em DESC LIMIT 1`, [req.user.colaboradorId]);
    if (!rows[0]) return res.json(null);
    res.json({ mapa: visaoMapa(rows[0], req.user), plano: await planoDoMapa(rows[0].id, req.user) });
  } catch (err) { next(err); }
}

/* =========================  MAPAS / PLANO (gestão)  ========================= */

async function listarMapas(req, res, next) {
  try {
    const p = [];
    let escopo = '1=1';
    if (req.user.perfilChave === 'lider_gestor') { p.push(req.user.colaboradorId); escopo = `c.gestor_id = $${p.length}`; }
    else if (req.user.perfilChave === 'gestor_rh' && req.user.empresaEscopoId) { p.push(req.user.empresaEscopoId); escopo = `c.empresa_id = $${p.length}`; }
    else if (req.user.perfilChave === 'colaborador') throw erro(403, 'Sem permissão.');
    const { rows } = await query(
      `SELECT m.*, c.nome AS colaborador_nome FROM lid_mapas m JOIN colaboradores c ON c.id = m.colaborador_id
       WHERE ${escopo} ORDER BY m.criado_em DESC`, p);
    res.json(rows.map((m) => visaoMapa(m, req.user)));
  } catch (err) { next(err); }
}

async function detalheMapa(req, res, next) {
  try {
    const { rows } = await query('SELECT m.*, c.nome AS colaborador_nome FROM lid_mapas m JOIN colaboradores c ON c.id = m.colaborador_id WHERE m.id = $1', [req.params.id]);
    if (!rows[0] || !(await podeVerColaborador(req.user, rows[0].colaborador_id))) throw erro(404, 'Mapa não encontrado ou fora do seu escopo.');
    res.json({ mapa: visaoMapa(rows[0], req.user), plano: await planoDoMapa(rows[0].id, req.user) });
  } catch (err) { next(err); }
}

async function editarPlano(req, res, next) {
  try {
    const plano = (await query('SELECT * FROM lid_planos WHERE mapa_id = $1', [req.params.mapaId])).rows[0];
    if (!plano) throw erro(404, 'Plano não encontrado.');
    if (plano.status === 'no_pdi') throw erro(409, 'Plano já enviado ao PDI; ajuste as ações direto no PDI.');
    await withUserTransaction(req.user.id, async (c) => {
      for (const a of req.body.acoes || []) {
        await c.query(`UPDATE lid_plano_acoes SET incluir = COALESCE($1, incluir), titulo = COALESCE($2, titulo), descricao = COALESCE($3, descricao),
                       prazo_dias = COALESCE($4, prazo_dias), prioridade = COALESCE($5, prioridade) WHERE id = $6 AND plano_id = $7`,
          [a.incluir ?? null, a.titulo ?? null, a.descricao ?? null, a.prazoDias ?? null, a.prioridade ?? null, a.id, plano.id]);
      }
      for (const n of req.body.adicionar || []) {
        await c.query('INSERT INTO lid_plano_acoes (plano_id, titulo, descricao, tipo_acao, prazo_dias, prioridade) VALUES ($1,$2,$3,$4,$5,$6)',
          [plano.id, n.titulo, n.descricao || '', n.tipoAcao || 'pratica', n.prazoDias || 60, n.prioridade || 2]);
      }
      if (req.body.aprovar) await c.query("UPDATE lid_planos SET status = 'aprovado', aprovado_por = $1 WHERE id = $2", [req.user.id, plano.id]);
    });
    res.json({ ok: true });
  } catch (err) { next(err); }
}

async function regerarPlano(req, res, next) {
  try {
    const p = (await query('SELECT p.id, p.status, m.resultado FROM lid_planos p JOIN lid_mapas m ON m.id = p.mapa_id WHERE p.mapa_id = $1', [req.params.mapaId])).rows[0];
    if (!p) throw erro(404, 'Plano não encontrado.');
    if (p.status !== 'rascunho') throw erro(409, 'Só é possível regerar um plano em rascunho.');
    const motor = await carregarMotor();
    const acoes = S.gerarPlano(p.resultado, motor.regras, motor.cfg);
    await withUserTransaction(req.user.id, async (c) => {
      await c.query('DELETE FROM lid_plano_acoes WHERE plano_id = $1', [p.id]);
      await gravarAcoes(c, p.id, acoes);
    });
    res.json({ ok: true, acoes: acoes.length });
  } catch (err) { next(err); }
}

// Cada ação incluída vira uma linha em pdi_planos (módulo PDI existente, 002_*.sql).
async function enviarPdi(req, res, next) {
  try {
    const p = (await query('SELECT p.id, p.status, m.colaborador_id FROM lid_planos p JOIN lid_mapas m ON m.id = p.mapa_id WHERE p.mapa_id = $1', [req.params.mapaId])).rows[0];
    if (!p) throw erro(404, 'Plano não encontrado.');
    if (p.status !== 'aprovado') throw erro(409, 'Aprove o plano antes de enviá-lo ao PDI.');
    const n = await withUserTransaction(req.user.id, async (c) => {
      const ins = await c.query(
        `INSERT INTO pdi_planos (colaborador_id, ciclo, objetivo, acoes, prazo, status, origem, criado_por, mapa_id)
         SELECT $1, to_char(current_date,'YYYY') || '-S' || CASE WHEN extract(month FROM current_date) <= 6 THEN 1 ELSE 2 END,
                titulo, descricao, current_date + prazo_dias, 'em_andamento', 'mapa_lideranca', $2, $4
         FROM lid_plano_acoes WHERE plano_id = $3 AND incluir ORDER BY prioridade, id`,
        [p.colaborador_id, req.user.id, p.id, Number(req.params.mapaId)]);
      await c.query("UPDATE lid_planos SET status = 'no_pdi' WHERE id = $1", [p.id]);
      return ins.rowCount;
    });
    res.json({ ok: true, acoesCriadas: n });
  } catch (err) { next(err); }
}

async function consolidado(req, res, next) {
  try {
    const p = [];
    let filtro = '';
    const emp = req.user.empresaEscopoId || req.query.empresaId;
    if (emp) { p.push(emp); filtro = `AND c.empresa_id = $${p.length}`; }
    const { rows } = await query(
      `SELECT DISTINCT ON (m.colaborador_id) m.geral_pct, m.faixa_chave, m.confiabilidade, m.resultado
       FROM lid_mapas m JOIN colaboradores c ON c.id = m.colaborador_id
       WHERE true ${filtro} ORDER BY m.colaborador_id, m.criado_em DESC`, p);
    const porDim = {};
    const porFaixa = {};
    rows.forEach((m) => {
      porFaixa[m.faixa_chave] = (porFaixa[m.faixa_chave] || 0) + 1;
      m.resultado.dimensoes.forEach((d) => {
        if (d.pct === null) return;
        (porDim[d.chave] ||= { chave: d.chave, nome: d.nome, soma: 0, n: 0 });
        porDim[d.chave].soma += d.pct; porDim[d.chave].n += 1;
      });
    });
    const dimensoes = Object.values(porDim).map((d) => ({ chave: d.chave, nome: d.nome, mediaPct: Math.round(d.soma / d.n) })).sort((a, b) => a.mediaPct - b.mediaPct);
    const pendentes = (await query(
      `SELECT c.id, c.nome FROM colaboradores c WHERE c.status = 'ativo' ${filtro}
       AND EXISTS (SELECT 1 FROM colaboradores s WHERE s.gestor_id = c.id AND s.status <> 'desligado')
       AND NOT EXISTS (SELECT 1 FROM lid_mapas m WHERE m.colaborador_id = c.id) ORDER BY c.nome`, p)).rows;
    res.json({
      totalMapeados: rows.length, porFaixa, dimensoes,
      prioridadesDoGrupo: dimensoes.slice(0, 3).map((d) => d.chave),
      resultadosPoucoConfiaveis: rows.filter((m) => m.confiabilidade === 'baixa').length,
      lideresPendentes: pendentes,
    });
  } catch (err) { next(err); }
}

/* =========================  PAINEL DO RH: EDIÇÃO DO BANCO  ========================= */

async function bancoCompleto(req, res, next) {
  try {
    const dims = (await query('SELECT * FROM lid_dimensoes ORDER BY ordem')).rows;
    const qs = (await query(`SELECT q.*, EXISTS (SELECT 1 FROM lid_respostas r WHERE r.questao_id = q.id) AS respondida
                             FROM lid_questoes q ORDER BY q.dimensao_id, q.parte, q.ordem`)).rows;
    const ops = (await query('SELECT * FROM lid_opcoes ORDER BY questao_id, ordem')).rows;
    const questoes = qs.map((q) => ({ ...q, opcoes: ops.filter((o) => o.questao_id === q.id) }));
    res.json({
      dimensoes: dims, questoes,
      faixas: (await query('SELECT * FROM lid_faixas ORDER BY pct_min DESC')).rows,
      config: (await query('SELECT * FROM lid_config ORDER BY chave')).rows,
      avisos: S.avisosCobertura(questoes.filter((q) => q.ativo), dims),
    });
  } catch (err) { next(err); }
}

async function checarQuestao(b) {
  const erros = S.validarQuestao(b);
  if (!(await query('SELECT 1 FROM lid_dimensoes WHERE id = $1', [b.dimensaoId])).rowCount) erros.push('Dimensão inválida.');
  if (b.parId) {
    const par = (await query('SELECT dimensao_id FROM lid_questoes WHERE id = $1', [b.parId])).rows[0];
    if (!par) erros.push('Questão-par inexistente.');
    else if (par.dimensao_id !== Number(b.dimensaoId)) erros.push('A questão-par precisa ser da mesma dimensão.');
  }
  return erros;
}
async function inserirOpcoes(c, questaoId, opcoes) {
  for (const [i, o] of opcoes.entries()) {
    await c.query('INSERT INTO lid_opcoes (questao_id, texto, pontos, vitrine, ordem) VALUES ($1,$2,$3,$4,$5)', [questaoId, o.texto.trim(), o.pontos, !!o.vitrine, i]);
  }
}

async function criarQuestao(req, res, next) {
  try {
    const b = req.body;
    const erros = await checarQuestao(b);
    if (erros.length) return res.status(422).json({ erro: 'Questão inválida.', detalhes: erros });
    const id = await withUserTransaction(req.user.id, async (c) => {
      const { rows } = await c.query(
        `INSERT INTO lid_questoes (dimensao_id, parte, tipo, texto, par_id, ordem)
         VALUES ($1,$2,$3,$4,$5,(SELECT COALESCE(MAX(ordem),0)+1 FROM lid_questoes)) RETURNING id`,
        [b.dimensaoId, b.parte, b.tipo, b.texto.trim(), b.parId || null]);
      await inserirOpcoes(c, rows[0].id, b.opcoes);
      return rows[0].id;
    });
    res.status(201).json({ id });
  } catch (err) { next(err); }
}

// Questão já respondida => cria NOVA versão (mapas antigos continuam íntegros).
async function atualizarQuestao(req, res, next) {
  try {
    const b = req.body;
    const atual = (await query('SELECT * FROM lid_questoes WHERE id = $1', [req.params.id])).rows[0];
    if (!atual) throw erro(404, 'Questão não encontrada.');
    const erros = await checarQuestao(b);
    if (erros.length) return res.status(422).json({ erro: 'Questão inválida.', detalhes: erros });
    const respondida = (await query('SELECT 1 FROM lid_respostas WHERE questao_id = $1 LIMIT 1', [atual.id])).rowCount > 0;

    const resultado = await withUserTransaction(req.user.id, async (c) => {
      if (!respondida) {
        await c.query('UPDATE lid_questoes SET dimensao_id=$1, parte=$2, tipo=$3, texto=$4, par_id=$5 WHERE id=$6', [b.dimensaoId, b.parte, b.tipo, b.texto.trim(), b.parId || null, atual.id]);
        await c.query('DELETE FROM lid_opcoes WHERE questao_id = $1', [atual.id]);
        await inserirOpcoes(c, atual.id, b.opcoes);
        return { id: atual.id, novaVersao: false };
      }
      const { rows } = await c.query(
        `INSERT INTO lid_questoes (dimensao_id, parte, tipo, texto, par_id, ordem, substitui_id) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
        [b.dimensaoId, b.parte, b.tipo, b.texto.trim(), b.parId || null, atual.ordem, atual.id]);
      await inserirOpcoes(c, rows[0].id, b.opcoes);
      await c.query('UPDATE lid_questoes SET ativo = FALSE WHERE id = $1', [atual.id]);
      await c.query('UPDATE lid_questoes SET par_id = $1 WHERE par_id = $2 AND ativo', [rows[0].id, atual.id]);
      return { id: rows[0].id, novaVersao: true };
    });
    res.json(resultado);
  } catch (err) { next(err); }
}

async function alternarQuestao(req, res, next) {
  try {
    await withUserTransaction(req.user.id, (c) => c.query('UPDATE lid_questoes SET ativo = $1 WHERE id = $2', [!!req.body.ativo, req.params.id]));
    res.json({ ok: true });
  } catch (err) { next(err); }
}

async function excluirQuestao(req, res, next) {
  try {
    if ((await query('SELECT 1 FROM lid_respostas WHERE questao_id = $1 LIMIT 1', [req.params.id])).rowCount) {
      throw erro(409, 'Esta questão já foi respondida em mapas existentes. Desative-a em vez de excluir.');
    }
    await withUserTransaction(req.user.id, (c) => c.query('DELETE FROM lid_questoes WHERE id = $1', [req.params.id]));
    res.json({ ok: true });
  } catch (err) { next(err); }
}

async function listarRegras(req, res, next) {
  try {
    res.json((await query('SELECT r.*, d.chave AS dim_chave FROM lid_regras_plano r LEFT JOIN lid_dimensoes d ON d.id = r.dimensao_id ORDER BY r.gatilho, d.ordem, r.pct_min')).rows);
  } catch (err) { next(err); }
}

function validarRegra(b) {
  const e = [];
  if (!['dimensao', 'consistencia', 'vitrine', 'faixa'].includes(b.gatilho)) e.push('Gatilho inválido.');
  if (!b.titulo || b.titulo.trim().length < 5) e.push('Título obrigatório.');
  if (!b.descricao || b.descricao.trim().length < 10) e.push('Descreva a ação (mínimo 10 caracteres).');
  if (b.gatilho === 'dimensao' && (!b.dimensaoId || b.pctMin == null || b.pctMax == null || b.pctMin > b.pctMax)) e.push('Regra por dimensão exige dimensão e faixa de % válida.');
  if (b.gatilho === 'faixa' && !b.faixaChave) e.push('Regra por faixa exige a faixa.');
  if (!(b.prazoDias >= 1 && b.prazoDias <= 365)) e.push('Prazo entre 1 e 365 dias.');
  if (![1, 2, 3].includes(Number(b.prioridade))) e.push('Prioridade deve ser 1, 2 ou 3.');
  return e;
}
async function salvarRegra(req, res, next) {
  try {
    const b = req.body;
    const e = validarRegra(b);
    if (e.length) return res.status(422).json({ erro: 'Regra inválida.', detalhes: e });
    const dim = b.gatilho === 'dimensao';
    const v = [b.gatilho, dim ? b.dimensaoId : null, dim ? b.pctMin : null, dim ? b.pctMax : null,
      b.gatilho === 'faixa' ? b.faixaChave : null, b.titulo.trim(), b.descricao.trim(), b.tipoAcao || 'pratica', b.prazoDias, b.prioridade, b.ativo !== false];
    const r = await withUserTransaction(req.user.id, (c) => (req.params.id
      ? c.query('UPDATE lid_regras_plano SET gatilho=$1,dimensao_id=$2,pct_min=$3,pct_max=$4,faixa_chave=$5,titulo=$6,descricao=$7,tipo_acao=$8,prazo_dias=$9,prioridade=$10,ativo=$11 WHERE id=$12 RETURNING id', [...v, req.params.id])
      : c.query('INSERT INTO lid_regras_plano (gatilho,dimensao_id,pct_min,pct_max,faixa_chave,titulo,descricao,tipo_acao,prazo_dias,prioridade,ativo) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id', v)));
    res.status(req.params.id ? 200 : 201).json({ id: r.rows[0]?.id });
  } catch (err) { next(err); }
}
async function excluirRegra(req, res, next) {
  try { await withUserTransaction(req.user.id, (c) => c.query('DELETE FROM lid_regras_plano WHERE id = $1', [req.params.id])); res.json({ ok: true }); }
  catch (err) { next(err); }
}

async function salvarConfig(req, res, next) {
  try {
    const lim = { limiar_gap: [5, 60], limiar_vitrine: [10, 100], max_dimensoes_plano: [1, 8], pct_dimensao_reforco: [50, 95] };
    await withUserTransaction(req.user.id, async (c) => {
      for (const [k, v] of Object.entries(req.body)) {
        if (!lim[k]) continue;
        if (!(Number(v) >= lim[k][0] && Number(v) <= lim[k][1])) throw erro(422, `${k} deve estar entre ${lim[k][0]} e ${lim[k][1]}.`);
        await c.query('UPDATE lid_config SET valor = $1 WHERE chave = $2', [Number(v), k]);
      }
    });
    res.json({ ok: true });
  } catch (err) { next(err); }
}

module.exports = {
  questionario, aplicarMapa, meuMapa, listarMapas, detalheMapa, editarPlano, regerarPlano, enviarPdi, consolidado,
  bancoCompleto, criarQuestao, atualizarQuestao, alternarQuestao, excluirQuestao, listarRegras, salvarRegra, excluirRegra, salvarConfig,
};
