const { query, withUserTransaction } = require('../config/db');
const { podeAcessarColaborador } = require('../utils/escopo');

function whereEscopo(req, params) {
  const { perfilChave, colaboradorId, empresaEscopoId } = req.user;
  if (perfilChave === 'colaborador') {
    params.push(colaboradorId);
    return `p.colaborador_id = $${params.length}`;
  }
  if (perfilChave === 'lider_gestor') {
    params.push(colaboradorId);
    return `c.gestor_id = $${params.length}`;
  }
  if (perfilChave === 'gestor_rh' && empresaEscopoId) {
    params.push(empresaEscopoId);
    return `c.empresa_id = $${params.length}`;
  }
  return '1=1';
}

async function listar(req, res, next) {
  try {
    const params = [];
    const escopo = whereEscopo(req, params);
    const { rows } = await query(
      `SELECT p.*, c.nome AS colaborador_nome
       FROM pdi_planos p
       JOIN colaboradores c ON c.id = p.colaborador_id
       WHERE ${escopo}
       ORDER BY p.criado_em DESC`,
      params
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function criar(req, res, next) {
  try {
    if (req.user.perfilChave === 'colaborador') {
      return res.status(403).json({ erro: 'Fale com seu líder ou o RH para registrar um PDI.' });
    }
    const { colaboradorId, ciclo, objetivo, acoes, prazo } = req.body;
    if (!colaboradorId || !ciclo || !objetivo || !acoes) {
      return res.status(400).json({ erro: 'colaboradorId, ciclo, objetivo e acoes são obrigatórios.' });
    }
    if (!(await podeAcessarColaborador(req.user, colaboradorId))) {
      return res.status(403).json({ erro: 'Este colaborador está fora do seu escopo.' });
    }
    const resultado = await withUserTransaction(req.user.id, (client) =>
      client.query(
        `INSERT INTO pdi_planos (colaborador_id, ciclo, objetivo, acoes, prazo, status, origem, criado_por)
         VALUES ($1,$2,$3,$4,$5,'em_andamento','manual',$6) RETURNING id`,
        [colaboradorId, ciclo, objetivo, acoes, prazo || null, req.user.id]
      )
    );
    res.status(201).json({ id: resultado.rows[0].id });
  } catch (err) {
    next(err);
  }
}

async function atualizar(req, res, next) {
  try {
    if (req.user.perfilChave === 'colaborador') {
      return res.status(403).json({ erro: 'Fale com seu líder ou o RH para editar este PDI.' });
    }
    const alvo = (await query('SELECT colaborador_id FROM pdi_planos WHERE id = $1', [req.params.id])).rows[0];
    if (!alvo || !(await podeAcessarColaborador(req.user, alvo.colaborador_id))) {
      return res.status(403).json({ erro: 'Este PDI está fora do seu escopo.' });
    }
    const camposPermitidos = ['objetivo', 'acoes', 'prazo', 'status'];
    const entradas = Object.entries(req.body).filter(([k]) => camposPermitidos.includes(k));
    if (!entradas.length) return res.status(400).json({ erro: 'Nada para atualizar.' });

    const setClauses = entradas.map(([k], i) => `${k} = $${i + 1}`);
    const params = entradas.map(([, v]) => v);
    params.push(req.params.id);

    await withUserTransaction(req.user.id, (client) =>
      client.query(`UPDATE pdi_planos SET ${setClauses.join(', ')} WHERE id = $${params.length}`, params)
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

module.exports = { listar, criar, atualizar };
