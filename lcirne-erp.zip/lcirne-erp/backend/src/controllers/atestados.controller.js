const { query, withUserTransaction } = require('../config/db');
const { podeAcessarColaborador } = require('../utils/escopo');

// Mesma lógica de escopo do controller de colaboradores, reaplicada aqui.
// Em um projeto maior isso viraria um helper compartilhado
// (src/utils/escopoColaborador.js) reutilizado por todos os módulos que
// listam dados "por colaborador" (treinamentos, pdi, avaliações, etc.).
function whereEscopo(req, params) {
  const { perfilChave, colaboradorId, empresaEscopoId } = req.user;
  if (perfilChave === 'colaborador') {
    params.push(colaboradorId);
    return `a.colaborador_id = $${params.length}`;
  }
  if (perfilChave === 'lider_gestor') {
    params.push(colaboradorId);
    return `c.gestor_id = $${params.length}`;
  }
  if (perfilChave === 'gestor_rh' && empresaEscopoId) {
    params.push(empresaEscopoId);
    return `c.empresa_id = $${params.length}`;
  }
  return '1=1';
}

async function listar(req, res, next) {
  try {
    const params = [];
    const escopo = whereEscopo(req, params);
    const { rows } = await query(
      `SELECT a.*, c.nome AS colaborador_nome
       FROM atestados_licencas a JOIN colaboradores c ON c.id = a.colaborador_id
       WHERE ${escopo}
       ORDER BY a.data_inicio DESC`,
      params
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function criar(req, res, next) {
  try {
    const { colaboradorId, tipo, dataInicio, dataFim, cid, motivo, arquivoUrl } = req.body;
    // Colaborador só pode abrir atestado para si mesmo.
    const alvoId = req.user.perfilChave === 'colaborador' ? req.user.colaboradorId : colaboradorId;
    if (!alvoId || !tipo || !dataInicio || !dataFim) {
      return res.status(400).json({ erro: 'colaboradorId, tipo, dataInicio e dataFim são obrigatórios.' });
    }
    if (req.user.perfilChave !== 'colaborador' && !(await podeAcessarColaborador(req.user, alvoId))) {
      return res.status(403).json({ erro: 'Este colaborador está fora do seu escopo.' });
    }
    const resultado = await withUserTransaction(req.user.id, (client) =>
      client.query(
        `INSERT INTO atestados_licencas (colaborador_id, tipo, data_inicio, data_fim, cid, motivo, arquivo_url)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
        [alvoId, tipo, dataInicio, dataFim, cid || null, motivo || null, arquivoUrl || null]
      )
    );
    res.status(201).json({ id: resultado.rows[0].id });
  } catch (err) {
    next(err);
  }
}

// Aprovar/recusar — só RH/Líder (colaborador não pode auto-aprovar; regra
// reforçada aqui além do RBAC de módulo).
async function decidir(req, res, next) {
  try {
    if (req.user.perfilChave === 'colaborador') {
      return res.status(403).json({ erro: 'Você não pode aprovar/recusar atestados.' });
    }
    const { status } = req.body; // 'aprovado' | 'recusado'
    const at = (await query('SELECT colaborador_id FROM atestados_licencas WHERE id = $1', [req.params.id])).rows[0];
    if (!at || !(await podeAcessarColaborador(req.user, at.colaborador_id, { permitirProprio: false }))) {
      return res.status(403).json({ erro: 'Atestado fora do seu escopo (ou é o seu próprio).' });
    }
    if (!['aprovado', 'recusado'].includes(status)) {
      return res.status(400).json({ erro: 'Status inválido.' });
    }
    await withUserTransaction(req.user.id, (client) =>
      client.query(
        `UPDATE atestados_licencas SET status = $1, aprovado_por = $2 WHERE id = $3`,
        [status, req.user.id, req.params.id]
      )
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

module.exports = { listar, criar, decidir };
