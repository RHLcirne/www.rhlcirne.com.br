const { query, withUserTransaction } = require('../config/db');

async function listar(req, res, next) {
  try {
    const { rows } = await query('SELECT id, chave, nome, ativo, ordem FROM modulos ORDER BY ordem');
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

// Ativar/desativar um módulo inteiro para todo o grupo.
async function alternarAtivo(req, res, next) {
  try {
    const { ativo } = req.body;
    await withUserTransaction(req.user.id, (client) =>
      client.query('UPDATE modulos SET ativo = $1 WHERE id = $2', [!!ativo, req.params.id])
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

// Matriz completa perfil x módulo x CRUD, para renderizar a tela de
// Configuração de Módulos de uma vez.
async function matrizPermissoes(req, res, next) {
  try {
    const { rows } = await query(`
      SELECT mp.id, m.chave AS modulo, p.chave AS perfil,
             mp.pode_criar, mp.pode_ler, mp.pode_atualizar, mp.pode_deletar
      FROM modulos_permissoes mp
      JOIN modulos m ON m.id = mp.modulo_id
      JOIN perfis p ON p.id = mp.perfil_id
      ORDER BY m.ordem, p.id`);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function atualizarPermissao(req, res, next) {
  try {
    const { podeCriar, podeLer, podeAtualizar, podeDeletar } = req.body;
    await withUserTransaction(req.user.id, (client) =>
      client.query(
        `UPDATE modulos_permissoes
         SET pode_criar = $1, pode_ler = $2, pode_atualizar = $3, pode_deletar = $4
         WHERE id = $5`,
        [!!podeCriar, !!podeLer, !!podeAtualizar, !!podeDeletar, req.params.id]
      )
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

// Campos customizados da ficha do colaborador
async function listarCamposCustom(req, res, next) {
  try {
    const { rows } = await query("SELECT * FROM campos_customizados WHERE entidade = 'colaborador' ORDER BY id");
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function criarCampoCustom(req, res, next) {
  try {
    const { chave, rotulo, tipo, opcoes } = req.body;
    if (!chave || !rotulo) return res.status(400).json({ erro: 'chave e rótulo são obrigatórios.' });
    const resultado = await withUserTransaction(req.user.id, (client) =>
      client.query(
        `INSERT INTO campos_customizados (entidade, chave, rotulo, tipo, opcoes)
         VALUES ('colaborador', $1, $2, $3, $4) RETURNING id`,
        [chave, rotulo, tipo || 'texto', opcoes ? JSON.stringify(opcoes) : null]
      )
    );
    res.status(201).json({ id: resultado.rows[0].id });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  listar, alternarAtivo, matrizPermissoes, atualizarPermissao,
  listarCamposCustom, criarCampoCustom,
};
