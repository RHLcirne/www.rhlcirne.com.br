const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { query, withUserTransaction } = require('../config/db');
const { podeGerirUsuario } = require('../utils/escopo');

// Escopo: admin_master vê todos os usuários do grupo; gestor_rh vê os
// usuários da(s) empresa(s) do seu escopo (empresa_escopo_id). Nenhum
// outro perfil chega até aqui (rota protegida por exigirPerfil).
function aplicarEscopo(req, whereParts, params) {
  if (req.user.perfilChave === 'gestor_rh' && req.user.empresaEscopoId) {
    params.push(req.user.empresaEscopoId);
    whereParts.push(`u.empresa_escopo_id = $${params.length}`);
  }
}

async function listar(req, res, next) {
  try {
    const where = [];
    const params = [];
    aplicarEscopo(req, where, params);
    const sql = `
      SELECT u.id, u.login, u.email, u.status, u.ultimo_login, u.precisa_trocar_senha,
             p.chave AS perfil, p.nome AS perfil_nome, u.colaborador_id, u.empresa_escopo_id
      FROM usuarios u JOIN perfis p ON p.id = u.perfil_id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY u.login`;
    const { rows } = await query(sql, params);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

function gerarSenhaTemporaria() {
  // 12 caracteres alfanuméricos legíveis (sem 0/O/1/l para reduzir erro de digitação)
  const alfabeto = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  return Array.from(crypto.randomFillSync(new Uint8Array(12)))
    .map((n) => alfabeto[n % alfabeto.length])
    .join('');
}

async function criar(req, res, next) {
  try {
    const { login, email, perfilChave, empresaEscopoId, colaboradorId } = req.body;
    if (!login || !perfilChave) {
      return res.status(400).json({ erro: 'Login e perfil são obrigatórios.' });
    }

    // gestor_rh só pode criar usuários dentro da própria empresa e nunca
    // pode criar admin_master (privilege escalation).
    if (req.user.perfilChave === 'gestor_rh') {
      if (perfilChave === 'admin_master') {
        return res.status(403).json({ erro: 'Você não pode atribuir o perfil Administrador Master.' });
      }
      if (req.user.empresaEscopoId && empresaEscopoId !== req.user.empresaEscopoId) {
        return res.status(403).json({ erro: 'Você só pode criar usuários dentro da sua empresa.' });
      }
    }

    const { rows: perfilRows } = await query('SELECT id FROM perfis WHERE chave = $1', [perfilChave]);
    if (!perfilRows[0]) return res.status(400).json({ erro: 'Perfil inválido.' });

    const senhaTemp = gerarSenhaTemporaria();
    const hash = await bcrypt.hash(senhaTemp, 10);

    const resultado = await withUserTransaction(req.user.id, (client) =>
      client.query(
        `INSERT INTO usuarios (login, email, senha_hash, perfil_id, empresa_escopo_id, colaborador_id, precisa_trocar_senha)
         VALUES ($1,$2,$3,$4,$5,$6, TRUE)
         RETURNING id, login, email, status`,
        [login, email || null, hash, perfilRows[0].id, empresaEscopoId || null, colaboradorId || null]
      )
    );

    // A senha temporária só aparece nesta resposta única (o hash é
    // irreversível a partir daqui) — o RH deve repassá-la ao colaborador
    // por um canal seguro.
    res.status(201).json({ ...resultado.rows[0], senhaTemporaria: senhaTemp });
  } catch (err) {
    next(err);
  }
}

async function atualizar(req, res, next) {
  try {
    const { id } = req.params;
    const { email, perfilChave, empresaEscopoId } = req.body;
    const perm = await podeGerirUsuario(req.user, id);
    if (!perm.ok) return res.status(perm.status).json({ erro: perm.erro });
    if (req.user.empresaEscopoId && empresaEscopoId !== undefined && empresaEscopoId !== req.user.empresaEscopoId) {
      return res.status(403).json({ erro: 'Você não pode mudar o escopo de empresa deste usuário.' });
    }

    const campos = [];
    const params = [];
    if (email !== undefined) { params.push(email); campos.push(`email = $${params.length}`); }
    if (empresaEscopoId !== undefined) { params.push(empresaEscopoId); campos.push(`empresa_escopo_id = $${params.length}`); }
    if (perfilChave) {
      if (req.user.perfilChave === 'gestor_rh' && perfilChave === 'admin_master') {
        return res.status(403).json({ erro: 'Você não pode atribuir o perfil Administrador Master.' });
      }
      const { rows } = await query('SELECT id FROM perfis WHERE chave = $1', [perfilChave]);
      if (!rows[0]) return res.status(400).json({ erro: 'Perfil inválido.' });
      params.push(rows[0].id); campos.push(`perfil_id = $${params.length}`);
    }
    if (!campos.length) return res.status(400).json({ erro: 'Nada para atualizar.' });

    params.push(id);
    await withUserTransaction(req.user.id, (client) =>
      client.query(`UPDATE usuarios SET ${campos.join(', ')} WHERE id = $${params.length}`, params)
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

// Bloquear / desbloquear (não deleta — mantém histórico e auditoria)
async function alterarStatus(req, res, next) {
  try {
    const { id } = req.params;
    const { status } = req.body; // 'ativo' | 'bloqueado' | 'inativo'
    const perm = await podeGerirUsuario(req.user, id);
    if (!perm.ok) return res.status(perm.status).json({ erro: perm.erro });
    if (Number(id) === req.user.id && status !== 'ativo') return res.status(400).json({ erro: 'Você não pode bloquear a própria conta.' });
    if (!['ativo', 'bloqueado', 'inativo'].includes(status)) {
      return res.status(400).json({ erro: 'Status inválido.' });
    }
    await withUserTransaction(req.user.id, (client) =>
      client.query(
        `UPDATE usuarios SET status = $1, tentativas_login = 0 WHERE id = $2`,
        [status, id]
      )
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

// RH redefine a senha de qualquer colaborador diretamente (sem precisar
// do fluxo de e-mail) — gera uma senha temporária de uso único.
async function redefinirSenha(req, res, next) {
  try {
    const { id } = req.params;
    const perm = await podeGerirUsuario(req.user, id);
    if (!perm.ok) return res.status(perm.status).json({ erro: perm.erro });
    const senhaTemp = gerarSenhaTemporaria();
    const hash = await bcrypt.hash(senhaTemp, 10);
    await withUserTransaction(req.user.id, (client) =>
      client.query(
        `UPDATE usuarios SET senha_hash = $1, precisa_trocar_senha = TRUE, status = 'ativo', tentativas_login = 0 WHERE id = $2`,
        [hash, id]
      )
    );
    res.json({ ok: true, senhaTemporaria: senhaTemp });
  } catch (err) {
    next(err);
  }
}

module.exports = { listar, criar, atualizar, alterarStatus, redefinirSenha };
