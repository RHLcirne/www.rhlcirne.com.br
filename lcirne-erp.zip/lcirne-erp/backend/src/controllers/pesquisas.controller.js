const { query, withUserTransaction } = require('../config/db');

async function listarAtivas(req, res, next) {
  try {
    const { rows } = await query(
      `SELECT id, titulo, descricao, anonima, data_inicio, data_fim
       FROM pesquisas_clima
       WHERE ativo = TRUE AND now()::date BETWEEN data_inicio AND data_fim
         AND (empresa_id IS NULL OR empresa_id = (SELECT empresa_id FROM colaboradores WHERE id = $1))
       ORDER BY data_inicio DESC`,
      [req.user.colaboradorId]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function perguntas(req, res, next) {
  try {
    const { rows } = await query(
      `SELECT id, texto, tipo, opcoes, ordem FROM perguntas_pesquisa WHERE pesquisa_id = $1 ORDER BY ordem`,
      [req.params.id]
    );
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function criarPesquisa(req, res, next) {
  try {
    const { titulo, descricao, empresaId, anonima, dataInicio, dataFim, perguntas: listaPerguntas } = req.body;
    if (!titulo || !dataInicio || !dataFim) {
      return res.status(400).json({ erro: 'titulo, dataInicio e dataFim são obrigatórios.' });
    }
    const id = await withUserTransaction(req.user.id, async (client) => {
      const { rows } = await client.query(
        `INSERT INTO pesquisas_clima (titulo, descricao, empresa_id, anonima, data_inicio, data_fim, criado_por)
         VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
        [titulo, descricao || null, empresaId || null, anonima !== false, dataInicio, dataFim, req.user.id]
      );
      const pesquisaId = rows[0].id;
      for (const [i, p] of (listaPerguntas || []).entries()) {
        await client.query(
          `INSERT INTO perguntas_pesquisa (pesquisa_id, texto, tipo, opcoes, ordem)
           VALUES ($1,$2,$3,$4,$5)`,
          [pesquisaId, p.texto, p.tipo || 'escala_1_5', p.opcoes ? JSON.stringify(p.opcoes) : null, i]
        );
      }
      return pesquisaId;
    });
    res.status(201).json({ id });
  } catch (err) {
    next(err);
  }
}

// Responder: se a pesquisa é anônima, respondido_por só é usado para
// controlar "já respondeu" e nunca é retornado junto do conteúdo nos
// relatórios (ver resultados()).
async function responder(req, res, next) {
  try {
    const { respostas } = req.body; // [{ perguntaId, resposta }]
    if (!Array.isArray(respostas) || !respostas.length) {
      return res.status(400).json({ erro: 'Envie ao menos uma resposta.' });
    }
    if (!req.user.colaboradorId) return res.status(400).json({ erro: 'Usuário sem ficha de colaborador.' });
    const pesq = (await query('SELECT 1 FROM pesquisas_clima WHERE id = $1 AND ativo AND current_date BETWEEN data_inicio AND data_fim', [req.params.id])).rowCount;
    if (!pesq) return res.status(404).json({ erro: 'Pesquisa encerrada ou inexistente.' });
    const ja = (await query('SELECT 1 FROM respostas_pesquisa WHERE pesquisa_id = $1 AND respondido_por = $2 LIMIT 1', [req.params.id, req.user.colaboradorId])).rowCount;
    if (ja) return res.status(409).json({ erro: 'Você já respondeu esta pesquisa.' });
    await withUserTransaction(req.user.id, async (client) => {
      for (const r of respostas) {
        await client.query(
          `INSERT INTO respostas_pesquisa (pesquisa_id, pergunta_id, respondido_por, resposta)
           VALUES ($1,$2,$3,$4)`,
          [req.params.id, r.perguntaId, req.user.colaboradorId, r.resposta]
        );
      }
    });
    res.status(201).json({ ok: true });
  } catch (err) {
    next(err);
  }
}

// Resultados agregados — só RH/liderança (RBAC de módulo cuida disso).
// Nunca faz SELECT respondido_por junto do texto da resposta quando a
// pesquisa é anônima, preservando o anonimato mesmo para o RH.
async function resultados(req, res, next) {
  try {
    const { rows: pesquisaRows } = await query('SELECT anonima FROM pesquisas_clima WHERE id = $1', [req.params.id]);
    if (!pesquisaRows[0]) return res.status(404).json({ erro: 'Pesquisa não encontrada.' });

    const camposIdentidade = pesquisaRows[0].anonima ? '' : ', rp.respondido_por, c.nome AS respondido_por_nome';
    const joinIdentidade = pesquisaRows[0].anonima ? '' : 'LEFT JOIN colaboradores c ON c.id = rp.respondido_por';

    const { rows } = await query(
      `SELECT pp.texto AS pergunta, rp.resposta ${camposIdentidade}
       FROM respostas_pesquisa rp
       JOIN perguntas_pesquisa pp ON pp.id = rp.pergunta_id
       ${joinIdentidade}
       WHERE rp.pesquisa_id = $1
       ORDER BY pp.ordem`,
      [req.params.id]
    );
    res.json({ anonima: pesquisaRows[0].anonima, respostas: rows });
  } catch (err) {
    next(err);
  }
}

module.exports = { listarAtivas, perguntas, criarPesquisa, responder, resultados };
