const { query, withUserTransaction } = require('../config/db');
const { podeAcessarColaborador } = require('../utils/escopo');

const CAMPOS_LISTA = `
  c.id, c.nome, c.cargo, c.departamento, c.status, c.data_admissao,
  c.foto_url, c.empresa_id, e.nome AS empresa_nome, c.unidade_id, c.gestor_id`;

const CAMPOS_FICHA_COMPLETA = `
  c.*, e.nome AS empresa_nome, un.nome AS unidade_nome, g.nome AS gestor_nome`;

// Monta a cláusula WHERE de escopo conforme o perfil de quem está pedindo.
// Esta função é a barreira de segurança central do requisito 1:
//   - admin_master / gestor_rh: todo o grupo (ou 1 empresa, via query ?empresaId=)
//   - lider_gestor: SOMENTE colaboradores com gestor_id = seu colaboradorId
//   - colaborador: nunca chega aqui — usa /meus-dados (ver abaixo)
function aplicarEscopo(req, whereParts, params) {
  const { perfilChave, colaboradorId } = req.user;

  if (perfilChave === 'lider_gestor') {
    params.push(colaboradorId);
    whereParts.push(`c.gestor_id = $${params.length}`);
    return;
  }

  if (perfilChave === 'gestor_rh' && req.user.empresaEscopoId) {
    params.push(req.user.empresaEscopoId);
    whereParts.push(`c.empresa_id = $${params.length}`);
  }

  // filtro opcional por empresa, só para admin_master/gestor_rh sem escopo fixo
  if (req.query.empresaId && ['admin_master', 'gestor_rh'].includes(perfilChave)) {
    params.push(req.query.empresaId);
    whereParts.push(`c.empresa_id = $${params.length}`);
  }
}

async function listar(req, res, next) {
  try {
    // Colaborador comum jamais recebe uma listagem geral — reforço extra
    // além do RBAC de módulo, exatamente como pedido no briefing.
    if (req.user.perfilChave === 'colaborador') {
      return res.status(403).json({ erro: 'Use /api/colaborador/meus-dados para consultar sua própria ficha.' });
    }

    const where = ["c.status <> 'desligado' OR $1::boolean"];
    const params = [req.query.incluirDesligados === 'true'];
    aplicarEscopo(req, where, params);

    const sql = `
      SELECT ${CAMPOS_LISTA}
      FROM colaboradores c JOIN empresas e ON e.id = c.empresa_id
      WHERE ${where.join(' AND ')}
      ORDER BY c.nome`;
    const { rows } = await query(sql, params);
    res.json(rows);
  } catch (err) {
    next(err);
  }
}

async function buscarPorId(req, res, next) {
  try {
    if (req.user.perfilChave === 'colaborador') {
      return res.status(403).json({ erro: 'Use /api/colaborador/meus-dados.' });
    }

    const where = ['c.id = $1'];
    const params = [req.params.id];
    aplicarEscopo(req, where, params);

    const { rows } = await query(
      `SELECT ${CAMPOS_FICHA_COMPLETA}
       FROM colaboradores c
       JOIN empresas e ON e.id = c.empresa_id
       LEFT JOIN unidades un ON un.id = c.unidade_id
       LEFT JOIN colaboradores g ON g.id = c.gestor_id
       WHERE ${where.join(' AND ')}`,
      params
    );
    if (!rows[0]) return res.status(404).json({ erro: 'Colaborador não encontrado ou fora do seu escopo.' });
    res.json(rows[0]);
  } catch (err) {
    next(err);
  }
}

// Endpoint exclusivo de autoatendimento — sempre usa req.user.colaboradorId,
// nunca um :id vindo da URL, para que seja fisicamente impossível um
// colaborador acessar a ficha de outra pessoa por esta rota.
async function meusDados(req, res, next) {
  try {
    if (!req.user.colaboradorId) {
      return res.status(404).json({ erro: 'Este usuário não está vinculado a uma ficha de colaborador.' });
    }
    const { rows } = await query(
      `SELECT ${CAMPOS_FICHA_COMPLETA}
       FROM colaboradores c
       JOIN empresas e ON e.id = c.empresa_id
       LEFT JOIN unidades un ON un.id = c.unidade_id
       LEFT JOIN colaboradores g ON g.id = c.gestor_id
       WHERE c.id = $1`,
      [req.user.colaboradorId]
    );
    res.json(rows[0] || null);
  } catch (err) {
    next(err);
  }
}

async function criar(req, res, next) {
  try {
    const { nome, cpf, empresaId, unidadeId, gestorId, cargo, departamento, salario, dataAdmissao, telefone, emailPessoal } = req.body;
    if (!nome || !empresaId) return res.status(400).json({ erro: 'Nome e empresa são obrigatórios.' });

    // gestor_rh com escopo fixo só pode criar dentro da própria empresa
    if (req.user.perfilChave === 'gestor_rh' && req.user.empresaEscopoId && empresaId !== req.user.empresaEscopoId) {
      return res.status(403).json({ erro: 'Você só pode cadastrar colaboradores da sua empresa.' });
    }

    const resultado = await withUserTransaction(req.user.id, (client) =>
      client.query(
        `INSERT INTO colaboradores (nome, cpf, empresa_id, unidade_id, gestor_id, cargo, departamento, salario, data_admissao, telefone, email_pessoal)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
        [nome, cpf || null, empresaId, unidadeId || null, gestorId || null, cargo || null, departamento || null, salario || null, dataAdmissao || null, telefone || null, emailPessoal || null]
      )
    );
    res.status(201).json({ id: resultado.rows[0].id });
  } catch (err) {
    next(err);
  }
}

async function atualizar(req, res, next) {
  try {
    if (!(await podeAcessarColaborador(req.user, req.params.id, { permitirProprio: false }))) {
      return res.status(403).json({ erro: 'Este colaborador está fora do seu escopo (ou é você mesmo).' });
    }
    const camposPermitidos = ['nome','cpf','unidade_id','gestor_id','cargo','departamento','salario','data_admissao','data_demissao','status','telefone','email_pessoal','endereco','campos_extra'];
    const entradas = Object.entries(req.body).filter(([k]) => camposPermitidos.includes(k));
    if (!entradas.length) return res.status(400).json({ erro: 'Nada para atualizar.' });

    // salário só pode ser alterado por quem tem permissão de 'atualizar' no
    // módulo colaboradores E for admin_master/gestor_rh — líder não edita salário.
    if (entradas.some(([k]) => k === 'salario') && req.user.perfilChave === 'lider_gestor') {
      return res.status(403).json({ erro: 'Líderes não podem alterar salário. Procure o RH.' });
    }

    const setClauses = entradas.map(([k], i) => `${k} = $${i + 1}`);
    const params = entradas.map(([, v]) => v);
    params.push(req.params.id);

    await withUserTransaction(req.user.id, (client) =>
      client.query(`UPDATE colaboradores SET ${setClauses.join(', ')} WHERE id = $${params.length}`, params)
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

module.exports = { listar, buscarPorId, meusDados, criar, atualizar };
