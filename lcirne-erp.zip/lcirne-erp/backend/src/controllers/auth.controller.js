const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query, withUserTransaction } = require('../config/db');

const MAX_TENTATIVAS = Number(process.env.MAX_TENTATIVAS_LOGIN || 5);

function gerarToken(usuario) {
  return jwt.sign({ sub: usuario.id, perfil: usuario.perfil_chave }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '8h',
  });
}

async function login(req, res, next) {
  try {
    const { login, senha } = req.body;
    if (!login || !senha) {
      return res.status(400).json({ erro: 'Informe login e senha.' });
    }

    const { rows } = await query(
      `SELECT u.*, p.chave AS perfil_chave, p.nome AS perfil_nome
       FROM usuarios u JOIN perfis p ON p.id = u.perfil_id
       WHERE lower(u.login) = lower($1)`,
      [login]
    );
    const usuario = rows[0];

    // Mensagem genérica de propósito — não revela se o login existe ou não.
    const credenciaisInvalidas = () => res.status(401).json({ erro: 'Usuário ou senha inválidos.' });

    if (!usuario) return credenciaisInvalidas();

    if (usuario.status === 'bloqueado') {
      return res.status(403).json({ erro: 'Conta bloqueada. Procure o RH para desbloqueio.' });
    }
    if (usuario.status !== 'ativo') return credenciaisInvalidas();

    const senhaOk = await bcrypt.compare(senha, usuario.senha_hash);

    if (!senhaOk) {
      const tentativas = usuario.tentativas_login + 1;
      const bloquear = tentativas >= MAX_TENTATIVAS;
      await query(
        `UPDATE usuarios SET tentativas_login = $1, status = $2 WHERE id = $3`,
        [tentativas, bloquear ? 'bloqueado' : usuario.status, usuario.id]
      );
      if (bloquear) {
        return res.status(403).json({ erro: 'Conta bloqueada após várias tentativas inválidas. Procure o RH.' });
      }
      return credenciaisInvalidas();
    }

    await query(
      `UPDATE usuarios SET tentativas_login = 0, ultimo_login = now() WHERE id = $1`,
      [usuario.id]
    );

    const token = gerarToken(usuario);
    res.json({
      token,
      precisaTrocarSenha: usuario.precisa_trocar_senha,
      usuario: {
        id: usuario.id,
        login: usuario.login,
        perfil: usuario.perfil_chave,
        perfilNome: usuario.perfil_nome,
        colaboradorId: usuario.colaborador_id,
        empresaEscopoId: usuario.empresa_escopo_id,
      },
    });
  } catch (err) {
    next(err);
  }
}

// Usuário logado troca a própria senha (fluxo padrão + fluxo de
// "precisa_trocar_senha" no primeiro acesso).
async function trocarSenha(req, res, next) {
  try {
    const { senhaAtual, novaSenha } = req.body;
    if (!novaSenha || novaSenha.length < 8) {
      return res.status(400).json({ erro: 'A nova senha deve ter ao menos 8 caracteres.' });
    }

    const { rows } = await query('SELECT senha_hash FROM usuarios WHERE id = $1', [req.user.id]);
    const ok = await bcrypt.compare(senhaAtual || '', rows[0].senha_hash);
    if (!ok) return res.status(401).json({ erro: 'Senha atual incorreta.' });

    const novoHash = await bcrypt.hash(novaSenha, 10);
    await withUserTransaction(req.user.id, (client) =>
      client.query(
        `UPDATE usuarios SET senha_hash = $1, precisa_trocar_senha = FALSE WHERE id = $2`,
        [novoHash, req.user.id]
      )
    );
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

// Gera um token de redefinição de senha (equivalente ao RESET_TOKENS do
// protótipo). Em produção, envie por e-mail/SMS em vez de retornar no
// corpo da resposta — aqui ele é retornado só para permitir o fluxo em
// dev sem servidor de e-mail configurado.
async function solicitarReset(req, res, next) {
  try {
    // Sem serviço de e-mail configurado, NÃO existe autoatendimento de redefinição em produção:
    // devolver o token na resposta permitiria a qualquer pessoa tomar qualquer conta.
    // Em produção o RH redefine a senha pelo painel. O fluxo abaixo só existe em desenvolvimento.
    if (process.env.NODE_ENV === 'production') {
      return res.json({ ok: true, mensagem: 'Procure o RH para redefinir sua senha.' });
    }
    const { login } = req.body;
    const { rows } = await query('SELECT id FROM usuarios WHERE lower(login) = lower($1)', [login]);
    if (!rows[0]) return res.json({ ok: true });
    const { rows: tokenRows } = await query(
      `INSERT INTO reset_tokens (usuario_id, expira_em) VALUES ($1, now() + interval '30 minutes') RETURNING token`, [rows[0].id]);
    res.json({ ok: true, tokenDev: tokenRows[0].token });
  } catch (err) {
    next(err);
  }
}

async function confirmarReset(req, res, next) {
  try {
    const { token, novaSenha } = req.body;
    if (!novaSenha || novaSenha.length < 8) {
      return res.status(400).json({ erro: 'A nova senha deve ter ao menos 8 caracteres.' });
    }
    const { rows } = await query(
      `SELECT * FROM reset_tokens WHERE token = $1 AND usado = FALSE AND expira_em > now()`,
      [token]
    );
    const rec = rows[0];
    if (!rec) return res.status(400).json({ erro: 'Token inválido ou expirado.' });

    const novoHash = await bcrypt.hash(novaSenha, 10);
    await withUserTransaction(rec.usuario_id, async (client) => {
      await client.query(
        `UPDATE usuarios SET senha_hash = $1, precisa_trocar_senha = FALSE, status = 'ativo', tentativas_login = 0 WHERE id = $2`,
        [novoHash, rec.usuario_id]
      );
      await client.query(`UPDATE reset_tokens SET usado = TRUE WHERE id = $1`, [rec.id]);
    });
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
}

module.exports = { login, trocarSenha, solicitarReset, confirmarReset };
