const { query } = require('../config/db');

// Única fonte de verdade para "este usuário pode agir sobre este colaborador?".
// permitirProprio=false impede agir sobre si mesmo (ex.: aprovar o próprio atestado, editar a própria ficha).
async function podeAcessarColaborador(user, colaboradorId, { permitirProprio = true } = {}) {
  const id = Number(colaboradorId);
  if (!id) return false;
  const { rows } = await query('SELECT empresa_id, gestor_id FROM colaboradores WHERE id = $1', [id]);
  const c = rows[0];
  if (!c) return false;
  if (user.perfilChave === 'admin_master') return true;
  if (id === user.colaboradorId) return permitirProprio;
  if (user.perfilChave === 'gestor_rh') return !user.empresaEscopoId || c.empresa_id === user.empresaEscopoId;
  if (user.perfilChave === 'lider_gestor') return c.gestor_id === user.colaboradorId;
  return false;
}

// Quem pode gerir a conta de outro usuário (senha, bloqueio, perfil).
// Gestor/RH nunca gere Administrador Master (evita tomada de conta) e respeita o escopo de empresa.
async function podeGerirUsuario(user, alvoId) {
  const { rows } = await query('SELECT u.id, u.empresa_escopo_id, p.chave AS perfil FROM usuarios u JOIN perfis p ON p.id = u.perfil_id WHERE u.id = $1', [alvoId]);
  const alvo = rows[0];
  if (!alvo) return { ok: false, status: 404, erro: 'Usuário não encontrado.' };
  if (user.perfilChave === 'admin_master') return { ok: true, alvo };
  if (alvo.perfil === 'admin_master') return { ok: false, status: 403, erro: 'Somente um Administrador Master pode gerir esta conta.' };
  if (user.empresaEscopoId && alvo.empresa_escopo_id !== user.empresaEscopoId) return { ok: false, status: 403, erro: 'Este usuário está fora do seu escopo de empresa.' };
  return { ok: true, alvo };
}

module.exports = { podeAcessarColaborador, podeGerirUsuario };
