const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
});

pool.on('error', (err) => {
  console.error('Erro inesperado no pool do PostgreSQL:', err);
});

// Query simples (sem necessidade de contexto de usuário para auditoria)
function query(text, params) {
  return pool.query(text, params);
}

// Executa uma função dentro de uma transação, já com
// `app.current_user_id` setado para que os triggers de auditoria
// (fn_auditoria() no schema.sql) registrem quem fez a alteração.
async function withUserTransaction(usuarioId, fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT set_config($1, $2, true)', [
      'app.current_user_id',
      usuarioId ? String(usuarioId) : '',
    ]);
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { pool, query, withUserTransaction };
