// Rodar: DATABASE_URL=postgresql://... node --test test/
const test = require('node:test');
const assert = require('node:assert');
const { Pool } = require('pg');
const { apurar, gerarPlano, validarQuestao, avisosCobertura } = require('../src/services/lideranca.service');

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
let dims, faixas, regras, cfg, banco;

test.before(async () => {
  dims = (await pool.query('SELECT * FROM lid_dimensoes ORDER BY ordem')).rows;
  faixas = (await pool.query('SELECT * FROM lid_faixas')).rows;
  regras = (await pool.query('SELECT * FROM lid_regras_plano WHERE ativo')).rows;
  cfg = Object.fromEntries((await pool.query('SELECT chave, valor FROM lid_config')).rows.map((r) => [r.chave, Number(r.valor)]));
  const qs = (await pool.query(`SELECT q.*, d.chave AS dim_chave FROM lid_questoes q JOIN lid_dimensoes d ON d.id=q.dimensao_id WHERE q.ativo ORDER BY q.ordem`)).rows;
  const ops = (await pool.query('SELECT * FROM lid_opcoes')).rows;
  banco = qs.map((q) => ({ ...q, opcoes: ops.filter((o) => o.questao_id === q.id) }));
});
test.after(() => pool.end());

// estratégia recebe (questão) e devolve a opção escolhida
function responder(estrategia) {
  return banco.map((q) => {
    const o = estrategia(q);
    return { dimChave: q.dim_chave, parte: q.parte, tipo: q.tipo, questaoId: q.id, parId: q.par_id, pontos: o.pontos, vitrine: o.vitrine };
  });
}
const melhor = (q) => q.opcoes.reduce((a, b) => (b.pontos > a.pontos ? b : a));
const pior = (q) => q.opcoes.reduce((a, b) => (b.pontos < a.pontos ? b : a));

test('líder que acerta tudo: consolidado, sem alertas, sem ações por dimensão', () => {
  const r = apurar(responder(melhor), dims, faixas, cfg);
  assert.equal(r.geralPct, 100);
  assert.equal(r.faixaChave, 'consolidado');
  assert.equal(r.confiabilidade, 'alta');
  const plano = gerarPlano(r, regras, cfg);
  assert.ok(plano.every((a) => a.dimensaoId === null), 'não deve gerar ação por dimensão');
  assert.ok(plano.some((a) => a.titulo.startsWith('Atuar como mentor')));
});

test('líder "de vitrine": escolhe a opção que soa certa nas pegadinhas e a melhor nas demais', () => {
  const r = apurar(responder((q) => (q.tipo === 'pegadinha' ? q.opcoes.find((o) => o.vitrine) : melhor(q))), dims, faixas, cfg);
  assert.equal(r.indiceVitrine, 100);
  assert.ok(r.alertas.includes('respostas_de_vitrine'));
  assert.ok(r.alertas.includes('pares_divergentes'), 'acertou o espelho normal mas errou a pegadinha → divergência');
  assert.equal(r.confiabilidade, 'baixa');
  assert.ok(r.geralPct > 85, 'nota alta enganosa, por isso o alerta é necessário');
  const plano = gerarPlano(r, regras, cfg);
  assert.ok(plano.some((a) => a.titulo.includes('360')), 'plano deve pedir validação 360°');
  assert.equal(plano[0].prioridade, 1);
});

test('líder fraco em D3: plano prioriza D3 e limita a 3 dimensões', () => {
  const r = apurar(responder((q) => (q.dim_chave === 'D3' ? pior(q) : melhor(q))), dims, faixas, cfg);
  const d3 = r.dimensoes.find((d) => d.chave === 'D3');
  assert.ok(d3.pct < 40);
  const plano = gerarPlano(r, regras, cfg);
  const d3id = dims.find((d) => d.chave === 'D3').id;
  assert.ok(plano.some((a) => a.dimensaoId === d3id && a.prioridade === 1));
  assert.ok(new Set(plano.filter((a) => a.dimensaoId).map((a) => a.dimensaoId)).size <= cfg.max_dimensoes_plano);
});

test('líder que responde tudo mal: faixa de atenção e acompanhamento do RH', () => {
  const r = apurar(responder(pior), dims, faixas, cfg);
  assert.equal(r.faixaChave, 'atencao');
  const plano = gerarPlano(r, regras, cfg);
  assert.ok(plano.some((a) => a.titulo.startsWith('Acompanhamento próximo')));
  assert.equal(plano.filter((a) => a.dimensaoId).length <= cfg.max_dimensoes_plano, true);
});

test('validação: questão do RH', () => {
  const ok = { texto: 'Uma situação com texto suficientemente longo.', parte: 1, tipo: 'normal',
    opcoes: [{ texto: 'Opção A boa', pontos: 5 }, { texto: 'Opção B média', pontos: 3 }, { texto: 'Opção C ruim', pontos: 1 }] };
  assert.deepEqual(validarQuestao(ok), []);
  assert.ok(validarQuestao({ ...ok, tipo: 'pegadinha' }).length > 0, 'pegadinha sem vitrine deve falhar');
  const peg = { ...ok, tipo: 'pegadinha', opcoes: [{ texto: 'Soa bem mas erra', pontos: 2, vitrine: true }, ...ok.opcoes.slice(0, 2)] };
  assert.deepEqual(validarQuestao(peg), []);
  const vitrineMelhor = { ...peg, opcoes: [{ texto: 'Soa bem e é a melhor', pontos: 5, vitrine: true }, ...ok.opcoes.slice(1)] };
  assert.ok(validarQuestao(vitrineMelhor).length > 0, 'vitrine não pode ser a melhor');
  assert.ok(validarQuestao({ ...ok, opcoes: ok.opcoes.map((o) => ({ ...o, pontos: 3 })) }).length > 0, 'sem diferença de pontos');
  assert.ok(validarQuestao({ ...ok, texto: 'curto' }).length > 0);
});

test('cobertura do banco: seed está completo', () => {
  assert.deepEqual(avisosCobertura(banco, dims), []);
});
