// Pré-requisitos: banco com schema + 002 + 004 + 005 + test/fixtures.sql, servidor rodando.
//   BASE_URL=http://localhost:3333/api DATABASE_URL=... node --test test/lideranca.api.test.js
const test = require('node:test');
const assert = require('node:assert');
const { Pool } = require('pg');

const BASE = process.env.BASE_URL || 'http://localhost:3333/api';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const tk = {};
let mapaId, questaoRespondidaId;

async function http(metodo, caminho, token, corpo) {
  const r = await fetch(BASE + caminho, {
    method: metodo,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: corpo ? JSON.stringify(corpo) : undefined,
  });
  return { status: r.status, body: await r.json().catch(() => null) };
}
async function logar(login) {
  const r = await http('POST', '/auth/login', null, { login, senha: 'Teste#12345' });
  assert.equal(r.status, 200, `login ${login}`);
  return r.body.token;
}

test.before(async () => {
  tk.rh = await logar('rita.rh'); tk.lider = await logar('ana.lider'); tk.colab = await logar('bruno');
});
test.after(() => pool.end());

test('questionário não vaza pontos, vitrine, tipo, dimensão nem par', async () => {
  const r = await http('GET', '/lideranca/questionario', tk.lider);
  assert.equal(r.status, 200);
  assert.equal(r.body.length, 72);
  // confere as CHAVES (não o texto dos enunciados, que pode conter a palavra "pontos")
  const chavesQ = new Set(r.body.flatMap((q) => Object.keys(q)));
  const chavesO = new Set(r.body.flatMap((q) => q.opcoes.flatMap((o) => Object.keys(o))));
  assert.deepEqual([...chavesQ].sort(), ['id', 'opcoes', 'texto']);
  assert.deepEqual([...chavesO].sort(), ['id', 'texto']);
});

test('líder "de vitrine" responde: nota alta, mas RH vê confiabilidade baixa; líder não vê', async () => {
  const q = (await http('GET', '/lideranca/questionario', tk.lider)).body;
  const chave = (await pool.query(`SELECT o.id, o.questao_id, o.pontos, o.vitrine, qq.tipo FROM lid_opcoes o JOIN lid_questoes qq ON qq.id=o.questao_id`)).rows;
  const respostas = q.map((qs) => {
    const ops = chave.filter((o) => o.questao_id === qs.id);
    const esc = ops[0].tipo === 'pegadinha' ? ops.find((o) => o.vitrine) : ops.reduce((a, b) => (b.pontos > a.pontos ? b : a));
    return { questaoId: qs.id, opcaoId: esc.id };
  });
  const r = await http('POST', '/lideranca/mapas', tk.lider, { respostas });
  assert.equal(r.status, 201);
  mapaId = r.body.id;
  assert.ok(r.body.geralPct >= 85);
  for (const k of ['confiabilidade', 'indiceVitrine', 'alertas', 'paresDivergentes', 'gapMedio']) assert.ok(!(k in r.body), `líder viu ${k}`);

  const rh = await http('GET', `/lideranca/mapas/${mapaId}`, tk.rh);
  assert.equal(rh.status, 200);
  assert.equal(rh.body.mapa.confiabilidade, 'baixa');
  assert.equal(rh.body.mapa.indiceVitrine, 100);
  assert.ok(rh.body.plano.acoes.some((a) => a.titulo.includes('360')));
});

test('respostas incompletas ou forjadas são rejeitadas', async () => {
  const q = (await http('GET', '/lideranca/questionario', tk.lider)).body;
  const parcial = await http('POST', '/lideranca/mapas', tk.lider, { respostas: [{ questaoId: q[0].id, opcaoId: q[0].opcoes[0].id }] });
  assert.equal(parcial.status, 400);
  const forjada = await http('POST', '/lideranca/mapas', tk.lider, { respostas: [{ questaoId: q[0].id, opcaoId: q[1].opcoes[0].id }] });
  assert.equal(forjada.status, 400);
});

test('plano em rascunho fica oculto ao líder até o RH aprovar', async () => {
  const antes = await http('GET', '/lideranca/meu-mapa', tk.lider);
  assert.equal(antes.body.plano.status, 'em_revisao');
  assert.equal(antes.body.plano.acoes.length, 0);
});

test('RH edita plano, aprova e envia ao PDI (pdi_planos); reenvio é bloqueado', async () => {
  const det = await http('GET', `/lideranca/mapas/${mapaId}`, tk.rh);
  const acoes = det.body.plano.acoes;
  assert.ok(acoes.length >= 1);
  const semAprovar = await http('POST', `/lideranca/planos/${mapaId}/enviar-pdi`, tk.rh);
  assert.equal(semAprovar.status, 409);
  const ed = await http('PUT', `/lideranca/planos/${mapaId}`, tk.rh, {
    acoes: [{ id: acoes[0].id, incluir: false }],
    adicionar: [{ titulo: 'Mentoria com diretor comercial', descricao: 'Encontros quinzenais por 3 meses.', prazoDias: 90, prioridade: 2 }],
    aprovar: true,
  });
  assert.equal(ed.status, 200);
  const env = await http('POST', `/lideranca/planos/${mapaId}/enviar-pdi`, tk.rh);
  assert.equal(env.status, 200);
  assert.equal(env.body.acoesCriadas, acoes.length); // -1 desmarcada, +1 adicionada
  const n = (await pool.query("SELECT count(*)::int n FROM pdi_planos WHERE colaborador_id=902 AND origem='mapa_lideranca'")).rows[0].n;
  assert.equal(n, acoes.length);
  assert.equal((await http('POST', `/lideranca/planos/${mapaId}/enviar-pdi`, tk.rh)).status, 409);
  // módulo PDI existente lista os itens, ligados ao mapa de origem
  const pdi = await http('GET', '/pdi', tk.rh);
  assert.equal(pdi.status, 200);
  const doMapa = pdi.body.filter((x) => x.origem === 'mapa_lideranca');
  assert.equal(doMapa.length, acoes.length);
  assert.ok(doMapa.every((x) => x.mapa_id === mapaId && x.colaborador_id === 902));
  const vis = await http('GET', '/lideranca/meu-mapa', tk.lider);
  assert.equal(vis.body.plano.status, 'no_pdi');
  assert.ok(vis.body.plano.acoes.length >= 1);
});

test('permissões: líder e colaborador não acessam o painel do RH nem o de outros', async () => {
  assert.equal((await http('GET', '/lideranca/admin/banco', tk.lider)).status, 403);
  assert.equal((await http('POST', '/lideranca/admin/questoes', tk.lider, {})).status, 403);
  assert.equal((await http('GET', '/lideranca/consolidado', tk.lider)).status, 403);
  assert.equal((await http('GET', `/lideranca/mapas/${mapaId}`, tk.colab)).status, 403);
  assert.equal((await http('GET', '/lideranca/questionario')).status, 401);
});

test('líder vê mapas apenas dos seus liderados (não o próprio como "equipe")', async () => {
  const r = await http('GET', '/lideranca/mapas', tk.lider);
  assert.equal(r.status, 200);
  assert.ok(r.body.every((m) => m.colaboradorId === 903));
});

test('RH: rejeita pegadinha inválida com mensagens claras', async () => {
  const dim = (await pool.query("SELECT id FROM lid_dimensoes WHERE chave='D1'")).rows[0].id;
  const ruim = await http('POST', '/lideranca/admin/questoes', tk.rh, {
    dimensaoId: dim, parte: 1, tipo: 'pegadinha', texto: 'Situação de teste com enunciado longo o bastante.',
    opcoes: [{ texto: 'A melhor e ainda vitrine', pontos: 5, vitrine: true }, { texto: 'Opção mediana aqui', pontos: 3 }, { texto: 'Opção fraca aqui', pontos: 1 }],
  });
  assert.equal(ruim.status, 422);
  assert.ok(ruim.body.detalhes.some((d) => d.includes('vitrine')));
});

test('RH: cria pegadinha válida e edita questão já respondida => nova versão', async () => {
  const dim = (await pool.query("SELECT id FROM lid_dimensoes WHERE chave='D1'")).rows[0].id;
  const ok = await http('POST', '/lideranca/admin/questoes', tk.rh, {
    dimensaoId: dim, parte: 2, tipo: 'pegadinha', texto: 'Um vendedor pede para sair mais cedo pela terceira vez no mês.',
    opcoes: [{ texto: 'Libero sem perguntar, para manter o clima leve.', pontos: 2, vitrine: true },
             { texto: 'Pergunto o motivo, registro o combinado e ajusto a escala com a equipe.', pontos: 5 },
             { texto: 'Nego e aviso que vou reportar ao RH.', pontos: 2 }],
  });
  assert.equal(ok.status, 201);

  questaoRespondidaId = (await pool.query('SELECT questao_id FROM lid_respostas LIMIT 1')).rows[0].questao_id;
  const atual = (await http('GET', '/lideranca/admin/banco', tk.rh)).body.questoes.find((x) => x.id === questaoRespondidaId);
  assert.equal(atual.respondida, true);
  const edit = await http('PUT', `/lideranca/admin/questoes/${questaoRespondidaId}`, tk.rh, {
    dimensaoId: atual.dimensao_id, parte: atual.parte, tipo: atual.tipo, parId: atual.par_id,
    texto: atual.texto + ' (texto revisado pelo RH)',
    opcoes: atual.opcoes.map((o) => ({ texto: o.texto, pontos: o.pontos, vitrine: o.vitrine })),
  });
  assert.equal(edit.status, 200);
  assert.equal(edit.body.novaVersao, true);
  const antiga = (await pool.query('SELECT ativo FROM lid_questoes WHERE id=$1', [questaoRespondidaId])).rows[0];
  assert.equal(antiga.ativo, false);
  // mapa antigo continua íntegro (pontos são snapshot)
  const det = await http('GET', `/lideranca/mapas/${mapaId}`, tk.rh);
  assert.equal(det.status, 200);
  assert.equal(
    (await http('DELETE', `/lideranca/admin/questoes/${questaoRespondidaId}`, tk.rh)).status, 409, 'não deixa apagar questão já respondida');
});

test('consolidado do grupo e líderes pendentes', async () => {
  const r = await http('GET', '/lideranca/consolidado', tk.rh);
  assert.equal(r.status, 200);
  assert.equal(r.body.totalMapeados, 1);
  assert.equal(r.body.resultadosPoucoConfiaveis, 1);
  assert.equal(r.body.dimensoes.length, 8);
});

test('implementação anterior removida: rotas e tabelas antigas não existem mais', async () => {
  for (const rota of ['/mapa-lideranca/questoes', '/mapa-lideranca/aplicacoes']) {
    assert.equal((await http('GET', rota, tk.rh)).status, 404, rota);
  }
  const antigas = ['dimensoes_lideranca', 'questoes_lideranca', 'faixas_lideranca', 'aplicacoes_mapa_lideranca', 'respostas_mapa_lideranca', 'acoes_sugeridas_lideranca'];
  const { rows } = await pool.query('SELECT table_name FROM information_schema.tables WHERE table_name = ANY($1)', [antigas]);
  assert.deepEqual(rows, []);
});
