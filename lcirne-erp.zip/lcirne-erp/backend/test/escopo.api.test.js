// Autorização por escopo (IDOR / escalonamento de privilégio).
// Requer: banco com migrações + test/fixtures.sql + servidor em modo desenvolvimento.
const test = require('node:test');
const assert = require('node:assert');
const { Pool } = require('pg');
const BASE = process.env.BASE_URL || 'http://localhost:3333/api';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const tk = {};
async function http(m, p, t, b) {
  const r = await fetch(BASE + p, { method: m, headers: { 'Content-Type': 'application/json', ...(t ? { Authorization: `Bearer ${t}` } : {}) }, body: b ? JSON.stringify(b) : undefined });
  return { status: r.status, body: await r.json().catch(() => null) };
}
const logar = async (l) => (await http('POST', '/auth/login', null, { login: l, senha: 'Teste#12345' })).body.token;
test.before(async () => {
  // admin.master liberado só para o teste
  await pool.query(`UPDATE usuarios SET status='ativo', senha_hash=crypt('Teste#12345', gen_salt('bf',8)), precisa_trocar_senha=FALSE WHERE login='admin.master'`);
  await pool.query(`INSERT INTO colaboradores (id, empresa_id, nome, cargo) VALUES (910,2,'Carla Outra Empresa','Frentista') ON CONFLICT DO NOTHING`);
  await pool.query(`INSERT INTO atestados_licencas (id, colaborador_id, tipo, data_inicio, data_fim) VALUES (990, 910, 'atestado', current_date, current_date) ON CONFLICT DO NOTHING`);
  await pool.query(`INSERT INTO atestados_licencas (id, colaborador_id, tipo, data_inicio, data_fim) VALUES (991, 903, 'atestado', current_date, current_date) ON CONFLICT DO NOTHING`);
  await pool.query(`INSERT INTO pdi_planos (id, colaborador_id, ciclo, objetivo, acoes) VALUES (990, 910, '2026-S2', 'Objetivo alheio', 'acoes') ON CONFLICT DO NOTHING`);
  tk.rh = await logar('rita.rh'); tk.lider = await logar('ana.lider'); tk.colab = await logar('bruno'); tk.adm = await logar('admin.master');
});
test.after(() => pool.end());

test('líder NÃO edita colaborador fora da sua equipe, mas edita liderado', async () => {
  assert.notEqual((await http('PUT', '/colaboradores/910', tk.lider, { cargo: 'Hackeado' })).status, 200);
  assert.equal((await pool.query('SELECT cargo FROM colaboradores WHERE id=910')).rows[0].cargo, 'Frentista');
  assert.equal((await http('PUT', '/colaboradores/903', tk.lider, { cargo: 'Vendedor Sênior' })).status, 200);
});
test('líder NÃO edita a si mesmo (cargo/gestor/status)', async () => {
  assert.notEqual((await http('PUT', '/colaboradores/902', tk.lider, { cargo: 'Diretor' })).status, 200);
});
test('líder NÃO aprova atestado de fora da equipe, mas aprova de liderado', async () => {
  assert.notEqual((await http('PATCH', '/atestados/990/decisao', tk.lider, { status: 'aprovado' })).status, 200);
  assert.equal((await pool.query('SELECT status FROM atestados_licencas WHERE id=990')).rows[0].status, 'pendente');
  assert.equal((await http('PATCH', '/atestados/991/decisao', tk.lider, { status: 'aprovado' })).status, 200);
});
test('líder NÃO abre atestado nem PDI para quem não é da equipe', async () => {
  const hoje = new Date().toISOString().slice(0, 10);
  assert.notEqual((await http('POST', '/atestados', tk.lider, { colaboradorId: 910, tipo: 'atestado', dataInicio: hoje, dataFim: hoje })).status, 201);
  assert.notEqual((await http('POST', '/pdi', tk.lider, { colaboradorId: 910, ciclo: '2026-S2', objetivo: 'x', acoes: 'y' })).status, 201);
  assert.notEqual((await http('PUT', '/pdi/990', tk.lider, { objetivo: 'alterado' })).status, 200);
  assert.equal((await pool.query('SELECT objetivo FROM pdi_planos WHERE id=990')).rows[0].objetivo, 'Objetivo alheio');
});
test('Gestor/RH NÃO mexe no Administrador Master (senha, status, perfil, e-mail)', async () => {
  const adm = (await pool.query("SELECT id FROM usuarios WHERE login='admin.master'")).rows[0].id;
  assert.equal((await http('POST', `/usuarios/${adm}/redefinir-senha`, tk.rh)).status, 403);
  assert.equal((await http('PATCH', `/usuarios/${adm}/status`, tk.rh, { status: 'bloqueado' })).status, 403);
  assert.equal((await http('PUT', `/usuarios/${adm}`, tk.rh, { email: 'invasor@x.com' })).status, 403);
  assert.equal((await pool.query('SELECT status FROM usuarios WHERE id=$1', [adm])).rows[0].status, 'ativo');
});
test('Administrador Master não consegue bloquear a si mesmo', async () => {
  const adm = (await pool.query("SELECT id FROM usuarios WHERE login='admin.master'")).rows[0].id;
  assert.equal((await http('PATCH', `/usuarios/${adm}/status`, tk.adm, { status: 'bloqueado' })).status, 400);
});
test('colaborador não abre PDI nem aprova atestado', async () => {
  assert.equal((await http('POST', '/pdi', tk.colab, { colaboradorId: 903, ciclo: 'x', objetivo: 'x', acoes: 'y' })).status, 403);
  assert.notEqual((await http('PATCH', '/atestados/991/decisao', tk.colab, { status: 'aprovado' })).status, 200);
});
test('pesquisa: mesma pessoa não responde duas vezes', async () => {
  const { rows } = await pool.query(`INSERT INTO pesquisas_clima (titulo, anonima, data_inicio, data_fim) VALUES ('Clima teste', TRUE, current_date - 1, current_date + 5) RETURNING id`);
  const pid = rows[0].id;
  const q = (await pool.query(`INSERT INTO perguntas_pesquisa (pesquisa_id, texto) VALUES ($1,'Como você se sente?') RETURNING id`, [pid])).rows[0].id;
  assert.equal((await http('POST', `/pesquisas/${pid}/respostas`, tk.colab, { respostas: [{ perguntaId: q, resposta: '4' }] })).status, 201);
  assert.equal((await http('POST', `/pesquisas/${pid}/respostas`, tk.colab, { respostas: [{ perguntaId: q, resposta: '5' }] })).status, 409);
});

test('senha temporária: só permite trocar a senha; depois libera o acesso', async () => {
  const rhTok = tk.rh; const login = 'temp.' + Date.now();
  const u = await http('POST', '/usuarios', rhTok, { login, perfilChave: 'colaborador', colaboradorId: 903 });
  assert.equal(u.status, 201);
  const l = await http('POST', '/auth/login', null, { login, senha: u.body.senhaTemporaria });
  assert.equal(l.status, 200); assert.equal(l.body.precisaTrocarSenha, true);
  for (const rota of ['/colaborador/meus-dados', '/pdi', '/lideranca/questionario']) {
    const r = await http('GET', rota, l.body.token);
    assert.equal(r.status, 403, rota); assert.equal(r.body.codigo, 'TROCA_SENHA_OBRIGATORIA');
  }
  const troca = await http('POST', '/auth/trocar-senha', l.body.token, { senhaAtual: u.body.senhaTemporaria, novaSenha: 'OutraSenhaBoa#2026' });
  assert.equal(troca.status, 200);
  assert.equal((await http('GET', '/colaborador/meus-dados', l.body.token)).status, 200, 'libera após trocar');
});
