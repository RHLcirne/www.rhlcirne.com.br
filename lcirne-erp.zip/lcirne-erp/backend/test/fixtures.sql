-- Dados de teste: 1 RH, 1 líder (Ana) com 1 liderado (Bruno). Senha de todos: Teste#12345
INSERT INTO colaboradores (id, empresa_id, nome, cargo) VALUES (901,1,'Rita RH','Analista de RH'),(902,1,'Ana Líder','Gerente'),(903,1,'Bruno Liderado','Vendedor');
UPDATE colaboradores SET gestor_id = 902 WHERE id = 903;
INSERT INTO usuarios (login,senha_hash,perfil_id,colaborador_id,precisa_trocar_senha) VALUES
 ('rita.rh',  crypt('Teste#12345',gen_salt('bf',8)),(SELECT id FROM perfis WHERE chave='gestor_rh'),901,FALSE),
 ('ana.lider',crypt('Teste#12345',gen_salt('bf',8)),(SELECT id FROM perfis WHERE chave='lider_gestor'),902,FALSE),
 ('bruno',    crypt('Teste#12345',gen_salt('bf',8)),(SELECT id FROM perfis WHERE chave='colaborador'),903,FALSE);
