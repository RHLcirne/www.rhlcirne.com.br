// Ativa o Administrador Master com senha ALEATÓRIA, exibida uma única vez.
// O schema cria 'admin.master' BLOQUEADO com uma senha conhecida (a do repositório);
// só este script o libera — assim ninguém entra com a senha padrão.
// Uso: npm run bootstrap-admin            (ou ADMIN_INITIAL_PASSWORD=... para definir a senha)
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

(async () => {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const alfabeto = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  const senha = process.env.ADMIN_INITIAL_PASSWORD
    || Array.from(crypto.randomBytes(16)).map((b) => alfabeto[b % alfabeto.length]).join('') + '#7';
  if (senha.length < 12) throw new Error('ADMIN_INITIAL_PASSWORD precisa ter ao menos 12 caracteres.');
  const hash = await bcrypt.hash(senha, 12);
  const r = await pool.query(
    `UPDATE usuarios SET senha_hash=$1, status='ativo', precisa_trocar_senha=TRUE, tentativas_login=0 WHERE login='admin.master' RETURNING login`, [hash]);
  await pool.end();
  if (!r.rowCount) throw new Error("Usuário 'admin.master' não encontrado. Rode 'npm run migrate' antes.");
  console.log('\n==============================================');
  console.log(' Administrador Master liberado');
  console.log('   login: admin.master');
  console.log(`   senha: ${senha}`);
  console.log(' Troca obrigatória no primeiro acesso. ANOTE AGORA: não será exibida de novo.');
  console.log('==============================================\n');
})().catch((e) => { console.error('FALHA:', e.message); process.exit(1); });
