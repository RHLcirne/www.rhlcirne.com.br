// Aplica as migrações SQL em ordem, uma única vez cada (controle na tabela `migracoes`).
// Uso: npm run migrate   (lê DATABASE_URL)
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const DIR = process.env.MIGRATIONS_DIR || path.join(__dirname, '..', '..', 'database');
const ORDEM = ['schema.sql', '002_modulo_pdi.sql', '004_lideranca_banco_editavel.sql', '005_seed_lideranca_banco_editavel.sql'];

(async () => {
  const pool = new Pool({ connectionString: process.env.DATABASE_URL });
  const c = await pool.connect();
  try {
    await c.query('CREATE TABLE IF NOT EXISTS migracoes (arquivo TEXT PRIMARY KEY, aplicada_em TIMESTAMPTZ NOT NULL DEFAULT now())');
    // trava para duas instâncias não migrarem ao mesmo tempo
    await c.query('SELECT pg_advisory_lock(727272)');
    const feitas = new Set((await c.query('SELECT arquivo FROM migracoes')).rows.map((r) => r.arquivo));
    for (const f of ORDEM) {
      if (feitas.has(f)) { console.log(`= ${f} (já aplicada)`); continue; }
      const sql = fs.readFileSync(path.join(DIR, f), 'utf8');
      try {
        await c.query('BEGIN');
        await c.query(sql.replace(/^\s*BEGIN;\s*$/gim, '').replace(/^\s*COMMIT;\s*$/gim, ''));
        await c.query('INSERT INTO migracoes (arquivo) VALUES ($1)', [f]);
        await c.query('COMMIT');
        console.log(`+ ${f} aplicada`);
      } catch (e) { await c.query('ROLLBACK'); throw new Error(`${f}: ${e.message}`); }
    }
    await c.query('SELECT pg_advisory_unlock(727272)');
  } finally { c.release(); await pool.end(); }
})().catch((e) => { console.error('FALHA NA MIGRAÇÃO:', e.message); process.exit(1); });
